import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar as CalendarIcon, Download, Check, X, Edit, Trash2, Plus, FileSignature } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { SignaturePad } from '@/components/ui/signature-pad';
import { getAllBookings, reviewBooking, updateBooking, deleteBooking, createBooking, getVenues, checkVenueAvailability, userSignBooking, adminSignBooking } from '@/db/api';
import type { BookingDetail, BookingStatus, Venue, BookingDuration } from '@/types';
import { BOOKING_DURATION_LABELS, BOOKING_STATUS_LABELS, BOOKING_STATUS_COLORS } from '@/types';
import { toast } from 'sonner';
import { format as formatDate } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import * as XLSX from 'xlsx';

// 根据时间跨度计算是半天还是全天
function calculateDuration(startTime: string, endTime: string): BookingDuration {
  const [startHour, startMinute] = startTime.split(':').map(Number);
  const [endHour, endMinute] = endTime.split(':').map(Number);
  
  const startMinutes = startHour * 60 + startMinute;
  const endMinutes = endHour * 60 + endMinute;
  const durationMinutes = endMinutes - startMinutes;
  
  // 4小时（240分钟）以内算半天，超过算全天
  return durationMinutes <= 240 ? 'half_day' : 'full_day';
}

export default function BookingManagementPage() {
  const { profile } = useAuth();
  const [bookings, setBookings] = useState<BookingDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [manualEntryDialogOpen, setManualEntryDialogOpen] = useState(false);
  const [signDialogOpen, setSignDialogOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<BookingDetail | null>(null);
  const [reviewStatus, setReviewStatus] = useState<BookingStatus>('approved');
  const [adminNotes, setAdminNotes] = useState('');
  const [editPrice, setEditPrice] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [deleting, setDeleting] = useState(false);
  const [signatureData, setSignatureData] = useState('');
  const [signing, setSigning] = useState(false);
  const [adminSignature, setAdminSignature] = useState<string>('');
  
  // 手动录入表单状态
  const [venues, setVenues] = useState<Venue[]>([]);
  const [manualEntry, setManualEntry] = useState({
    venue_id: '',
    booking_date: undefined as Date | undefined,
    start_time: '09:00',
    end_time: '17:00',
    organization_name: '',
    contact_person: '',
    contact_phone: '',
    purpose: '',
    final_price: '',
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadBookings();
    loadVenues();
  }, []);

  const loadVenues = async () => {
    try {
      const data = await getVenues();
      setVenues(data.filter(v => v.is_active));
    } catch (error) {
      console.error('加载场地列表失败:', error);
    }
  };

  const loadBookings = async () => {
    try {
      setLoading(true);
      const data = await getAllBookings();
      setBookings(data);
    } catch (error) {
      toast.error('加载预定记录失败');
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async () => {
    if (!selectedBooking) return;
    
    // 如果是审批通过，验证管理员签名
    if (reviewStatus === 'approved' && !adminSignature) {
      toast.error('审批通过前必须完成管理员签名');
      return;
    }
    
    try {
      // 先审批
      await reviewBooking(selectedBooking.id, reviewStatus, adminNotes || undefined);
      
      // 如果是审批通过，保存管理员签名
      if (reviewStatus === 'approved' && adminSignature) {
        await adminSignBooking(selectedBooking.id, adminSignature);
      }
      
      const statusText = reviewStatus === 'approved' ? '通过' : '拒绝';
      toast.success(`预约审核${statusText}成功！预约单位：${selectedBooking.organization_name || '未知'}`, { duration: 3000 });
      
      setReviewDialogOpen(false);
      setSelectedBooking(null);
      setAdminNotes('');
      setAdminSignature('');
      
      // 刷新预定列表
      await loadBookings();
    } catch (error) {
      console.error('审核失败:', error);
      toast.error('审核失败，请检查网络连接或联系技术支持');
    }
  };

  const handleEditPrice = async () => {
    if (!selectedBooking) return;
    
    const price = Number.parseFloat(editPrice);
    if (Number.isNaN(price) || price < 0) {
      toast.error('请输入有效的价格');
      return;
    }
    
    try {
      await updateBooking(selectedBooking.id, { 
        final_price: price,
        admin_notes: adminNotes || null
      });
      
      const noteInfo = adminNotes ? `，备注：${adminNotes}` : '';
      toast.success(`价格已更新为 ¥${price}${noteInfo}`, { duration: 5000 });
      
      setEditDialogOpen(false);
      setSelectedBooking(null);
      setEditPrice('');
      setAdminNotes('');
      
      // 刷新预定列表
      await loadBookings();
    } catch (error) {
      console.error('更新价格失败:', error);
      toast.error('更新价格失败，请检查网络连接或联系技术支持');
    }
  };

  const handleDelete = async () => {
    if (!selectedBooking) return;
    
    try {
      setDeleting(true);
      await deleteBooking(selectedBooking.id);
      
      toast.success(`预约记录已删除！场地：${selectedBooking.venue?.name}，日期：${formatDate(new Date(selectedBooking.booking_date), 'yyyy-MM-dd')}`, { duration: 3000 });
      
      setDeleteDialogOpen(false);
      setSelectedBooking(null);
      
      // 刷新预定列表
      await loadBookings();
    } catch (error) {
      console.error('删除失败:', error);
      toast.error('删除失败，请检查网络连接或联系技术支持');
    } finally {
      setDeleting(false);
    }
  };

  const handleManualEntry = async () => {
    if (!profile || !manualEntry.booking_date) {
      toast.error('请填写完整信息');
      return;
    }
    
    if (!manualEntry.venue_id || !manualEntry.contact_person || !manualEntry.contact_phone) {
      toast.error('请填写必填项');
      return;
    }
    
    if (manualEntry.end_time <= manualEntry.start_time) {
      toast.error('结束时间必须晚于开始时间');
      return;
    }
    
    // 验证联系电话格式
    const phoneRegex = /^1[3-9]\d{9}$/;
    if (!phoneRegex.test(manualEntry.contact_phone)) {
      toast.error('请输入正确的手机号码（11位数字，以1开头）');
      return;
    }
    
    try {
      setSubmitting(true);
      
      // 检查场地是否可用
      const dateStr = formatDate(manualEntry.booking_date, 'yyyy-MM-dd');
      const isAvailable = await checkVenueAvailability(
        manualEntry.venue_id,
        dateStr,
        manualEntry.start_time + ':00',
        manualEntry.end_time + ':00'
      );
      
      if (!isAvailable) {
        toast.error('该时段已被预定，请选择其他时间');
        return;
      }
      
      // 计算duration和价格
      const duration = calculateDuration(manualEntry.start_time, manualEntry.end_time);
      const venue = venues.find(v => v.id === manualEntry.venue_id);
      
      if (!venue) {
        toast.error('场地不存在');
        return;
      }
      
      // 使用手动输入的价格，如果没有则使用默认价格
      let finalPrice = venue[duration === 'half_day' ? 'half_day_price' : 'full_day_price'];
      if (manualEntry.final_price) {
        const customPrice = Number.parseFloat(manualEntry.final_price);
        if (!Number.isNaN(customPrice) && customPrice >= 0) {
          finalPrice = customPrice;
        }
      }
      
      // 创建预定（直接approved状态）
      await createBooking({
        venue_id: manualEntry.venue_id,
        user_id: profile.id, // 使用管理员ID
        booking_date: dateStr,
        start_time: manualEntry.start_time + ':00',
        end_time: manualEntry.end_time + ':00',
        duration: duration,
        status: 'approved', // 直接通过
        original_price: finalPrice,
        final_price: finalPrice,
        organization_name: manualEntry.organization_name || null,
        contact_person: manualEntry.contact_person,
        contact_phone: manualEntry.contact_phone,
        purpose: manualEntry.purpose || null,
        admin_notes: '管理员手动录入',
        user_signature: null,
        user_signature_date: null,
        admin_signature: null,
        admin_signature_date: null,
      });
      
      // 显示详细的成功提示
      const successMessage = `预定录入成功！
场地：${venue.name}
日期：${formatDate(manualEntry.booking_date, 'yyyy年MM月dd日', { locale: zhCN })}
时间：${manualEntry.start_time} - ${manualEntry.end_time}
联系人：${manualEntry.contact_person}
费用：¥${finalPrice}`;
      
      toast.success(successMessage, { duration: 5000 });
      
      setManualEntryDialogOpen(false);
      
      // 重置表单
      setManualEntry({
        venue_id: '',
        booking_date: undefined,
        start_time: '09:00',
        end_time: '17:00',
        organization_name: '',
        contact_person: '',
        contact_phone: '',
        purpose: '',
        final_price: '',
      });
      
      // 刷新预定列表
      await loadBookings();
    } catch (error) {
      console.error('手动录入失败:', error);
      toast.error('录入失败，请检查网络连接或联系技术支持');
    } finally {
      setSubmitting(false);
    }
  };

  const handleExport = () => {
    const exportData = bookings.map((booking) => ({
      场地名称: booking.venue?.name || '',
      场地类型: booking.venue ? booking.venue.type : '',
      预定日期: formatDate(new Date(booking.booking_date), 'yyyy-MM-dd'),
      开始时间: booking.start_time.substring(0, 5),
      结束时间: booking.end_time.substring(0, 5),
      预定时长: BOOKING_DURATION_LABELS[booking.duration],
      预定用户: booking.user?.username || '',
      单位名称: booking.organization_name || '',
      联系人: booking.contact_person || '',
      联系电话: booking.contact_phone || '',
      使用目的: booking.purpose || '',
      原始价格: booking.original_price,
      最终价格: booking.final_price,
      状态: BOOKING_STATUS_LABELS[booking.status],
      管理员备注: booking.admin_notes || '',
      创建时间: formatDate(new Date(booking.created_at), 'yyyy-MM-dd HH:mm:ss'),
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '预定记录');
    
    const fileName = `场地预定记录_${formatDate(new Date(), 'yyyyMMdd_HHmmss')}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast.success('导出成功');
  };

  // 导出单个预约的签字表
  const handleExportSingleSignatureSheet = (booking: BookingDetail) => {
    // 检查是否已通过审批
    if (booking.status !== 'approved') {
      toast.error('只能导出已通过审批的预约签字表');
      return;
    }

    // 生成 HTML 签字表
    const htmlContent = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>苏州市人才市场场地使用明细</title>
  <style>
    @media print {
      @page {
        size: A4;
        margin: 15mm;
      }
      .page-break {
        page-break-after: always;
      }
      button {
        display: none;
      }
    }
    
    body {
      font-family: "Microsoft YaHei", "SimSun", sans-serif;
      font-size: 14px;
      line-height: 1.6;
      color: #333;
      max-width: 210mm;
      margin: 0 auto;
      padding: 20px;
      background: #f5f5f5;
    }
    
    .print-button {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 24px;
      background: #3b82f6;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      z-index: 1000;
    }
    
    .print-button:hover {
      background: #2563eb;
    }
    
    .signature-sheet {
      background: white;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      border-radius: 8px;
    }
    
    .header {
      text-align: center;
      margin-bottom: 30px;
      border-bottom: 2px solid #333;
      padding-bottom: 15px;
    }
    
    .header h1 {
      font-size: 24px;
      font-weight: bold;
      margin: 0 0 10px 0;
      color: #1a1a1a;
    }
    
    .header .subtitle {
      font-size: 16px;
      color: #666;
    }
    
    .info-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    
    .info-table td {
      padding: 12px;
      border: 1px solid #ddd;
    }
    
    .info-table .label {
      background: #f8f9fa;
      font-weight: bold;
      width: 120px;
      color: #555;
    }
    
    .info-table .value {
      color: #333;
    }
    
    .signature-section {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #ddd;
    }
    
    .signature-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 50px;
    }
    
    .signature-item {
      flex: 1;
      text-align: center;
    }
    
    .signature-item .label {
      font-weight: bold;
      margin-bottom: 40px;
      color: #555;
    }
    
    .signature-item .line {
      border-bottom: 1px solid #333;
      width: 200px;
      margin: 0 auto 10px auto;
      height: 40px;
    }
    
    .signature-item .date-label {
      color: #666;
      font-size: 12px;
    }
    
    .footer {
      margin-top: 30px;
      padding-top: 15px;
      border-top: 1px solid #ddd;
      text-align: center;
      color: #999;
      font-size: 12px;
    }
    
    .notes {
      background: #fffbeb;
      border-left: 4px solid #f59e0b;
      padding: 15px;
      margin-top: 20px;
      border-radius: 4px;
    }
    
    .notes h3 {
      margin: 0 0 10px 0;
      font-size: 14px;
      color: #92400e;
    }
    
    .notes ul {
      margin: 0;
      padding-left: 20px;
      color: #78350f;
    }
    
    .notes li {
      margin-bottom: 5px;
    }
  </style>
</head>
<body>
  <button class="print-button" onclick="window.print()">打印/导出PDF</button>
  
  <div class="signature-sheet">
    <div class="header">
      <h1>苏州市人才市场场地使用明细</h1>
      <div class="subtitle">Venue Usage Details</div>
    </div>
    
    <table class="info-table">
      <tr>
        <td class="label">场地名称</td>
        <td class="value" colspan="3">${booking.venue?.name || ''}</td>
      </tr>
      <tr>
        <td class="label">场地类型</td>
        <td class="value">${booking.venue?.type || ''}</td>
        <td class="label">容纳人数</td>
        <td class="value">${booking.venue?.capacity || ''} 人</td>
      </tr>
      <tr>
        <td class="label">使用单位</td>
        <td class="value">${booking.organization_name || '个人'}</td>
        <td class="label">联系人</td>
        <td class="value">${booking.contact_person || ''}</td>
      </tr>
      <tr>
        <td class="label">联系电话</td>
        <td class="value">${booking.contact_phone || ''}</td>
        <td class="label">使用日期</td>
        <td class="value">${formatDate(new Date(booking.booking_date), 'yyyy年MM月dd日', { locale: zhCN })}</td>
      </tr>
      <tr>
        <td class="label">使用时间</td>
        <td class="value" colspan="3">${booking.start_time.substring(0, 5)} - ${booking.end_time.substring(0, 5)}</td>
      </tr>
      <tr>
        <td class="label">使用目的</td>
        <td class="value" colspan="3">${booking.purpose || ''}</td>
      </tr>
      <tr>
        <td class="label">费用</td>
        <td class="value" colspan="3">¥${booking.final_price.toFixed(2)}</td>
      </tr>
      ${booking.admin_notes ? `
      <tr>
        <td class="label">备注</td>
        <td class="value" colspan="3">${booking.admin_notes}</td>
      </tr>
      ` : ''}
    </table>
    
    <div class="notes">
      <h3>使用须知</h3>
      <ul>
        <li>请保持场地整洁，使用后请将桌椅归位</li>
        <li>请爱护场地设施，如有损坏请及时报告并照价赔偿</li>
        <li>禁止在场地内吸烟</li>
        <li>使用结束后请关闭电源、门窗</li>
        <li>如需延长使用时间，请提前联系管理人员</li>
      </ul>
    </div>
    
    <div class="signature-section">
      <div class="signature-row">
        <div class="signature-item">
          <div class="label">使用人签字：</div>
          ${booking.user_signature ? `
            <img src="${booking.user_signature}" alt="使用人签名" style="max-height: 80px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px;" />
            <div class="date-label">日期：${booking.user_signature_date ? formatDate(new Date(booking.user_signature_date), 'yyyy年MM月dd日', { locale: zhCN }) : ''}</div>
          ` : `
            <div class="line"></div>
            <div class="date-label">日期：____年____月____日</div>
          `}
        </div>
        <div class="signature-item">
          <div class="label">管理员签字：</div>
          ${booking.admin_signature ? `
            <img src="${booking.admin_signature}" alt="管理员签名" style="max-height: 80px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px;" />
            <div class="date-label">日期：${booking.admin_signature_date ? formatDate(new Date(booking.admin_signature_date), 'yyyy年MM月dd日', { locale: zhCN }) : ''}</div>
          ` : `
            <div class="line"></div>
            <div class="date-label">日期：____年____月____日</div>
          `}
        </div>
      </div>
    </div>
    
    <div class="footer">
      苏州市人才市场 · 场地管理部门<br>
      导出时间：${formatDate(new Date(), 'yyyy-MM-dd HH:mm:ss')}
    </div>
  </div>
  
  <script>
    // 自动打开打印对话框（可选）
    // window.onload = function() {
    //   setTimeout(function() {
    //     window.print();
    //   }, 500);
    // };
  </script>
</body>
</html>
    `;

    // 创建 Blob 并下载
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `场地使用明细_${booking.venue?.name}_${formatDate(new Date(), 'yyyyMMdd_HHmmss')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success('场地使用明细已导出，请打开文件后点击"打印/导出PDF"按钮');
  };

  // 打开签字对话框
  const handleOpenSignDialog = (booking: BookingDetail) => {
    // 检查是否已通过审批
    if (booking.status !== 'approved') {
      toast.error('只能为已通过审批的预约签字');
      return;
    }

    setSelectedBooking(booking);
    setSignatureData('');
    setSignDialogOpen(true);
  };

  // 提交签字
  const handleSubmitSignature = async (signature: string) => {
    if (!selectedBooking || !signature) {
      toast.error('请先完成签名');
      return;
    }

    try {
      setSigning(true);
      
      // 判断是使用人签字还是管理员签字
      const isAdmin = profile?.role === 'admin';
      
      if (isAdmin) {
        // 管理员签字
        await adminSignBooking(selectedBooking.id, signature);
        toast.success('管理员签字成功');
      } else {
        // 使用人签字
        await userSignBooking(selectedBooking.id, signature);
        toast.success('使用人签字成功');
      }
      
      setSignDialogOpen(false);
      setSignatureData('');
      loadBookings();
    } catch (error) {
      toast.error('签字失败');
    } finally {
      setSigning(false);
    }
  };

  const filteredBookings = bookings.filter((booking) => {
    if (activeTab === 'all') return true;
    return booking.status === activeTab;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">预定管理</h1>
          <p className="text-muted-foreground mt-2">审核和管理所有场地预定</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setManualEntryDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            手动录入
          </Button>
          <Button onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            导出Excel
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>预定记录</CardTitle>
          <CardDescription>共 {bookings.length} 条记录</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">全部</TabsTrigger>
              <TabsTrigger value="pending">待审核</TabsTrigger>
              <TabsTrigger value="approved">已通过</TabsTrigger>
              <TabsTrigger value="rejected">已拒绝</TabsTrigger>
              <TabsTrigger value="completed">已完成</TabsTrigger>
              <TabsTrigger value="cancelled">已取消</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>场地</TableHead>
                      <TableHead>用户</TableHead>
                      <TableHead>日期</TableHead>
                      <TableHead>时长</TableHead>
                      <TableHead>联系人</TableHead>
                      <TableHead>费用</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{booking.venue?.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {booking.venue && booking.venue.type}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{booking.user?.username}</div>
                            {booking.organization_name && (
                              <div className="text-xs text-muted-foreground">
                                {booking.organization_name}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {formatDate(new Date(booking.booking_date), 'yyyy-MM-dd')}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {booking.start_time.substring(0, 5)} - {booking.end_time.substring(0, 5)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {BOOKING_DURATION_LABELS[booking.duration]}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="text-sm">{booking.contact_person}</div>
                            <div className="text-xs text-muted-foreground">
                              {booking.contact_phone}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">¥{booking.final_price}</div>
                            {booking.original_price !== booking.final_price && (
                              <div className="text-xs text-muted-foreground line-through">
                                ¥{booking.original_price}
                              </div>
                            )}
                            {booking.admin_notes && (
                              <div className="text-xs text-muted-foreground mt-1" title={booking.admin_notes}>
                                📝 {booking.admin_notes.length > 10 ? booking.admin_notes.substring(0, 10) + '...' : booking.admin_notes}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={BOOKING_STATUS_COLORS[booking.status]}>
                            {BOOKING_STATUS_LABELS[booking.status]}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2 flex-wrap">
                            {booking.status === 'pending' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedBooking(booking);
                                  setReviewStatus('approved');
                                  setAdminSignature('');
                                  setReviewDialogOpen(true);
                                }}
                              >
                                <Check className="mr-2 h-4 w-4" />
                                审核
                              </Button>
                            )}
                            {booking.status === 'approved' && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleOpenSignDialog(booking)}
                                >
                                  <FileSignature className="mr-2 h-4 w-4" />
                                  签字
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleExportSingleSignatureSheet(booking)}
                                >
                                  <Download className="mr-2 h-4 w-4" />
                                  导出明细
                                </Button>
                              </>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedBooking(booking);
                                setEditPrice(booking.final_price.toString());
                                setAdminNotes(booking.admin_notes || '');
                                setEditDialogOpen(true);
                              }}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              改价
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedBooking(booking);
                                setDeleteDialogOpen(true);
                              }}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              删除
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {filteredBookings.length === 0 && (
                <div className="flex flex-col items-center justify-center py-12">
                  <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">暂无记录</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* 审核对话框 */}
      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto max-w-[95vw] xl:max-w-lg">
          <DialogHeader>
            <DialogTitle>审核预定</DialogTitle>
            <DialogDescription>
              {selectedBooking?.venue?.name} - {selectedBooking && formatDate(new Date(selectedBooking.booking_date), 'yyyy-MM-dd')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-3">
              {/* 预约详情 - 紧凑布局 */}
              <div className="space-y-1.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">预定用户：</span>
                  <span>{selectedBooking.user?.username}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">联系人：</span>
                  <span>{selectedBooking.contact_person}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">联系电话：</span>
                  <span>{selectedBooking.contact_phone}</span>
                </div>
                {selectedBooking.purpose && (
                  <div>
                    <span className="text-muted-foreground">使用目的：</span>
                    <p className="mt-0.5 text-xs">{selectedBooking.purpose}</p>
                  </div>
                )}
              </div>

              {/* 使用人签名显示 - 缩小尺寸 */}
              {selectedBooking.user_signature && (
                <div className="space-y-1.5">
                  <Label className="text-sm">使用人签名</Label>
                  <div className="p-2 border rounded-lg bg-muted">
                    <img 
                      src={selectedBooking.user_signature} 
                      alt="使用人签名" 
                      className="max-h-16 mx-auto border rounded bg-white"
                    />
                    <div className="text-xs text-center text-muted-foreground mt-1">
                      {selectedBooking.user_signature_date && 
                        formatDate(new Date(selectedBooking.user_signature_date), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                    </div>
                  </div>
                </div>
              )}

              {/* 审核结果 */}
              <div className="space-y-1.5">
                <Label className="text-sm">审核结果</Label>
                <Select value={reviewStatus} onValueChange={(value) => setReviewStatus(value as BookingStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">通过</SelectItem>
                    <SelectItem value="rejected">拒绝</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 管理员签名（仅审批通过时需要） - 响应式尺寸 */}
              {reviewStatus === 'approved' && (
                <div className="space-y-1.5">
                  <Alert className="bg-yellow-50 border-yellow-200 py-2">
                    <FileSignature className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      <strong>提示：</strong>审批通过前必须完成签名
                    </AlertDescription>
                  </Alert>
                  
                  <Label className="text-sm font-semibold">管理员签名 *</Label>
                  {adminSignature ? (
                    <div className="space-y-1.5">
                      <div className="p-2 border rounded-lg bg-muted">
                        <img 
                          src={adminSignature} 
                          alt="管理员签名" 
                          className="max-h-16 mx-auto border rounded bg-white"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setAdminSignature('')}
                        className="w-full"
                      >
                        重新签名
                      </Button>
                    </div>
                  ) : (
                    <SignaturePad
                      onSave={(signature) => {
                        setAdminSignature(signature);
                        toast.success('管理员签名已保存');
                      }}
                      width={280}
                      height={120}
                    />
                  )}
                </div>
              )}

              {/* 备注 */}
              <div className="space-y-1.5">
                <Label className="text-sm">备注（可选）</Label>
                <Textarea
                  placeholder="填写审核备注"
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={2}
                  className="text-sm"
                />
              </div>
            </div>
          )}
          
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setReviewDialogOpen(false)}>
              取消
            </Button>
            <Button 
              onClick={handleReview}
              disabled={reviewStatus === 'approved' && !adminSignature}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 改价对话框 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>修改价格</DialogTitle>
            <DialogDescription>
              {selectedBooking?.venue?.name} - {selectedBooking && formatDate(new Date(selectedBooking.booking_date), 'yyyy-MM-dd')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>原始价格</Label>
                <Input value={`¥${selectedBooking.original_price}`} disabled />
              </div>

              <div className="space-y-2">
                <Label>最终价格</Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="输入最终价格"
                  value={editPrice}
                  onChange={(e) => setEditPrice(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>改价原因（可选）</Label>
                <Textarea
                  placeholder="请说明改价原因，例如：优惠活动、特殊情况等"
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleEditPrice}>
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>
              此操作将永久删除该预定记录，无法恢复。
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">场地：</span>
                <span className="font-medium">{selectedBooking.venue?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">预定日期：</span>
                <span className="font-medium">
                  {formatDate(new Date(selectedBooking.booking_date), 'yyyy-MM-dd')}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">预定时间：</span>
                <span className="font-medium">
                  {selectedBooking.start_time.substring(0, 5)} - {selectedBooking.end_time.substring(0, 5)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">预定人：</span>
                <span className="font-medium">
                  {selectedBooking.organization_name || selectedBooking.user?.username}
                </span>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={deleting}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? '删除中...' : '确认删除'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 手动录入对话框 */}
      <Dialog open={manualEntryDialogOpen} onOpenChange={setManualEntryDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>手动录入预定</DialogTitle>
            <DialogDescription>
              管理员可直接录入预定记录，无需审核
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* 场地选择 */}
            <div className="space-y-2">
              <Label>场地 <span className="text-destructive">*</span></Label>
              <Select
                value={manualEntry.venue_id}
                onValueChange={(value) => setManualEntry({ ...manualEntry, venue_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择场地" />
                </SelectTrigger>
                <SelectContent>
                  {venues.map((venue) => (
                    <SelectItem key={venue.id} value={venue.id}>
                      {venue.name} - {venue.type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 预定日期 */}
            <div className="space-y-2">
              <Label>预定日期 <span className="text-destructive">*</span></Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !manualEntry.booking_date && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {manualEntry.booking_date ? (
                      formatDate(manualEntry.booking_date, 'yyyy-MM-dd', { locale: zhCN })
                    ) : (
                      '选择日期（可选历史日期）'
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={manualEntry.booking_date}
                    onSelect={(date) => setManualEntry({ ...manualEntry, booking_date: date })}
                    locale={zhCN}
                  />
                </PopoverContent>
              </Popover>
              <p className="text-xs text-muted-foreground">
                💡 提示：可以选择历史日期，用于补录之前的预约记录
              </p>
            </div>

            {/* 时间段 */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>开始时间 <span className="text-destructive">*</span></Label>
                <Input
                  type="time"
                  value={manualEntry.start_time}
                  onChange={(e) => setManualEntry({ ...manualEntry, start_time: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>结束时间 <span className="text-destructive">*</span></Label>
                <Input
                  type="time"
                  value={manualEntry.end_time}
                  onChange={(e) => setManualEntry({ ...manualEntry, end_time: e.target.value })}
                />
              </div>
            </div>

            {/* 预计时长和费用 */}
            {manualEntry.venue_id && manualEntry.start_time && manualEntry.end_time && (
              <div className="bg-muted p-3 rounded-lg space-y-1">
                <div className="text-sm">
                  <span className="text-muted-foreground">预计时长：</span>
                  <span className="font-medium ml-2">
                    {BOOKING_DURATION_LABELS[calculateDuration(manualEntry.start_time, manualEntry.end_time)]}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">默认费用：</span>
                  <span className="font-medium ml-2">
                    ¥{venues.find(v => v.id === manualEntry.venue_id)?.[
                      calculateDuration(manualEntry.start_time, manualEntry.end_time) === 'half_day' 
                        ? 'half_day_price' 
                        : 'full_day_price'
                    ] || 0}
                  </span>
                </div>
              </div>
            )}

            {/* 单位名称 */}
            <div className="space-y-2">
              <Label>单位名称</Label>
              <Input
                placeholder="填写单位名称（可选）"
                value={manualEntry.organization_name}
                onChange={(e) => setManualEntry({ ...manualEntry, organization_name: e.target.value })}
              />
            </div>

            {/* 联系人 */}
            <div className="space-y-2">
              <Label>联系人 <span className="text-destructive">*</span></Label>
              <Input
                placeholder="联系人姓名"
                value={manualEntry.contact_person}
                onChange={(e) => setManualEntry({ ...manualEntry, contact_person: e.target.value })}
              />
            </div>

            {/* 联系电话 */}
            <div className="space-y-2">
              <Label>联系电话 <span className="text-destructive">*</span></Label>
              <Input
                placeholder="联系电话"
                value={manualEntry.contact_phone}
                onChange={(e) => setManualEntry({ ...manualEntry, contact_phone: e.target.value })}
              />
            </div>

            {/* 使用目的 */}
            <div className="space-y-2">
              <Label>使用目的</Label>
              <Textarea
                placeholder="简要说明使用目的（可选）"
                value={manualEntry.purpose}
                onChange={(e) => setManualEntry({ ...manualEntry, purpose: e.target.value })}
                rows={3}
              />
            </div>

            {/* 自定义费用 */}
            <div className="space-y-2">
              <Label>自定义费用（可选）</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="留空则使用默认费用"
                value={manualEntry.final_price}
                onChange={(e) => setManualEntry({ ...manualEntry, final_price: e.target.value })}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setManualEntryDialogOpen(false)} disabled={submitting}>
              取消
            </Button>
            <Button onClick={handleManualEntry} disabled={submitting}>
              {submitting ? '录入中...' : '确认录入'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 签字对话框 */}
      <Dialog open={signDialogOpen} onOpenChange={setSignDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>场地使用签字</DialogTitle>
            <DialogDescription>
              请确认预约信息并签字
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              {/* 预约信息 */}
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground">场地名称</div>
                    <div className="font-medium">{selectedBooking.venue?.name}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">使用日期</div>
                    <div className="font-medium">
                      {formatDate(new Date(selectedBooking.booking_date), 'yyyy年MM月dd日', { locale: zhCN })}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">使用时间</div>
                    <div className="font-medium">
                      {selectedBooking.start_time.substring(0, 5)} - {selectedBooking.end_time.substring(0, 5)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">费用</div>
                    <div className="font-medium">¥{selectedBooking.final_price.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">使用单位</div>
                    <div className="font-medium">{selectedBooking.organization_name || '个人'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">联系人</div>
                    <div className="font-medium">{selectedBooking.contact_person}</div>
                  </div>
                </div>
              </div>

              {/* 使用须知 */}
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                <h4 className="font-semibold text-yellow-800 mb-2">使用须知</h4>
                <ul className="text-sm text-yellow-700 space-y-1">
                  <li>• 请保持教室整洁，使用后请将桌椅归位</li>
                  <li>• 请爱护教室设施，如有损坏请及时报告并照价赔偿</li>
                  <li>• 禁止在教室内吸烟、饮食</li>
                  <li>• 使用结束后请关闭电源、门窗</li>
                  <li>• 如需延长使用时间，请提前联系管理人员</li>
                </ul>
              </div>

              {/* 签字状态 */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="text-sm text-muted-foreground mb-2">使用人签字</div>
                  {selectedBooking.user_signature ? (
                    <div>
                      <img 
                        src={selectedBooking.user_signature} 
                        alt="使用人签名" 
                        className="max-h-20 border rounded"
                      />
                      <div className="text-xs text-muted-foreground mt-1">
                        {selectedBooking.user_signature_date && 
                          formatDate(new Date(selectedBooking.user_signature_date), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                      </div>
                    </div>
                  ) : (
                    <div className="text-muted-foreground">未签字</div>
                  )}
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-sm text-muted-foreground mb-2">管理员签字</div>
                  {selectedBooking.admin_signature ? (
                    <div>
                      <img 
                        src={selectedBooking.admin_signature} 
                        alt="管理员签名" 
                        className="max-h-20 border rounded"
                      />
                      <div className="text-xs text-muted-foreground mt-1">
                        {selectedBooking.admin_signature_date && 
                          formatDate(new Date(selectedBooking.admin_signature_date), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                      </div>
                    </div>
                  ) : (
                    <div className="text-muted-foreground">未签字</div>
                  )}
                </div>
              </div>

              {/* 签名板 */}
              <div className="space-y-2">
                <Label>
                  {profile?.role === 'admin' ? '管理员签名' : '使用人签名'}
                </Label>
                <SignaturePad
                  onSave={(signature) => {
                    setSignatureData(signature);
                    handleSubmitSignature(signature);
                  }}
                  width={400}
                  height={150}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSignDialogOpen(false)} disabled={signing}>
              取消
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
