import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Calendar, Building2, Clock, DollarSign, X, CheckCircle2, XCircle, AlertCircle, FileText } from 'lucide-react';
import { getUserBookings, cancelBooking } from '@/db/api';
import type { BookingDetail } from '@/types';
import { BOOKING_DURATION_LABELS, BOOKING_STATUS_LABELS, BOOKING_STATUS_COLORS } from '@/types';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function MyBookingsPage() {
  const { profile } = useAuth();
  const [bookings, setBookings] = useState<BookingDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState<BookingDetail | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<BookingDetail | null>(null);

  useEffect(() => {
    if (profile) {
      loadBookings();
    }
  }, [profile]);

  const loadBookings = async () => {
    if (!profile) return;
    
    try {
      setLoading(true);
      const data = await getUserBookings(profile.id);
      setBookings(data);
    } catch (error) {
      toast.error('加载预定记录失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!bookingToCancel) return;
    
    try {
      await cancelBooking(bookingToCancel.id);
      toast.success('预定已取消');
      setCancelDialogOpen(false);
      setBookingToCancel(null);
      loadBookings();
    } catch (error) {
      toast.error('取消预定失败');
    }
  };

  const canCancel = (booking: BookingDetail) => {
    return booking.status === 'pending' || booking.status === 'approved';
  };

  // 获取审核流程图标
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'approved':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-blue-500" />;
      case 'cancelled':
        return <XCircle className="h-5 w-5 text-gray-500" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">我的预定</h1>
        <p className="text-muted-foreground mt-2">查看和管理您的场地预定</p>
      </div>

      {bookings.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">暂无预定记录</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>预定记录</CardTitle>
            <CardDescription>共 {bookings.length} 条记录</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>场地</TableHead>
                    <TableHead>日期</TableHead>
                    <TableHead>时长</TableHead>
                    <TableHead>费用</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bookings.map((booking) => (
                    <TableRow key={booking.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{booking.venue?.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {booking.venue && booking.venue.type}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {format(new Date(booking.booking_date), 'yyyy-MM-dd', { locale: zhCN })}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {booking.start_time.substring(0, 5)} - {booking.end_time.substring(0, 5)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {BOOKING_DURATION_LABELS[booking.duration]}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">¥{booking.final_price}</div>
                          {booking.original_price !== booking.final_price && (
                            <div className="text-xs text-muted-foreground line-through">
                              ¥{booking.original_price}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(booking.status)}
                          <Badge className={BOOKING_STATUS_COLORS[booking.status]}>
                            {BOOKING_STATUS_LABELS[booking.status]}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedBooking(booking);
                              setDetailDialogOpen(true);
                            }}
                          >
                            <FileText className="mr-2 h-4 w-4" />
                            详情
                          </Button>
                          {canCancel(booking) && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setBookingToCancel(booking);
                                setCancelDialogOpen(true);
                              }}
                            >
                              <X className="mr-2 h-4 w-4" />
                              取消
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 预定详情对话框 */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>预定详情</DialogTitle>
            <DialogDescription>查看预定的详细信息和审核状态</DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              {/* 基本信息 */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">场地：</span>
                  <span className="font-medium">{selectedBooking.venue?.name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">日期：</span>
                  <span>{format(new Date(selectedBooking.booking_date), 'yyyy-MM-dd', { locale: zhCN })}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">时间：</span>
                  <span>
                    {selectedBooking.start_time.substring(0, 5)} - {selectedBooking.end_time.substring(0, 5)}
                  </span>
                  <Badge variant="outline" className="ml-2">
                    {BOOKING_DURATION_LABELS[selectedBooking.duration]}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">费用：</span>
                  <span className="font-medium">¥{selectedBooking.final_price}</span>
                  {selectedBooking.original_price !== selectedBooking.final_price && (
                    <span className="text-xs text-muted-foreground line-through">
                      (原价 ¥{selectedBooking.original_price})
                    </span>
                  )}
                </div>
              </div>

              <Separator />

              {/* 联系信息 */}
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">联系信息</h4>
                {selectedBooking.organization_name && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">单位：</span>
                    <span className="ml-2">{selectedBooking.organization_name}</span>
                  </div>
                )}
                <div className="text-sm">
                  <span className="text-muted-foreground">联系人：</span>
                  <span className="ml-2">{selectedBooking.contact_person}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">电话：</span>
                  <span className="ml-2">{selectedBooking.contact_phone}</span>
                </div>
                {selectedBooking.purpose && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">使用目的：</span>
                    <p className="mt-1 text-sm">{selectedBooking.purpose}</p>
                  </div>
                )}
              </div>

              <Separator />

              {/* 审核流程 */}
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">审核流程</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-100 dark:bg-green-900">
                      <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium">提交申请</div>
                      <div className="text-xs text-muted-foreground">
                        {format(new Date(selectedBooking.created_at), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                      </div>
                    </div>
                  </div>

                  <div className="ml-4 border-l-2 border-muted h-4"></div>

                  <div className="flex items-center gap-3">
                    <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                      selectedBooking.status === 'pending' 
                        ? 'bg-yellow-100 dark:bg-yellow-900' 
                        : selectedBooking.status === 'approved' || selectedBooking.status === 'completed'
                        ? 'bg-green-100 dark:bg-green-900'
                        : 'bg-red-100 dark:bg-red-900'
                    }`}>
                      {getStatusIcon(selectedBooking.status)}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium">
                        {selectedBooking.status === 'pending' && '等待审核'}
                        {selectedBooking.status === 'approved' && '审核通过'}
                        {selectedBooking.status === 'rejected' && '审核拒绝'}
                        {selectedBooking.status === 'completed' && '已完成'}
                        {selectedBooking.status === 'cancelled' && '已取消'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {selectedBooking.status === 'pending' && '管理员正在审核您的申请'}
                        {selectedBooking.status === 'approved' && '您的预定已通过审核'}
                        {selectedBooking.status === 'rejected' && '您的预定未通过审核'}
                        {selectedBooking.status === 'completed' && '预定已完成'}
                        {selectedBooking.status === 'cancelled' && '预定已取消'}
                      </div>
                    </div>
                  </div>

                  {selectedBooking.admin_notes && (
                    <>
                      <div className="ml-4 border-l-2 border-muted h-4"></div>
                      <div className="ml-11 p-3 bg-muted rounded-lg">
                        <div className="text-xs font-medium text-muted-foreground mb-1">管理员备注</div>
                        <div className="text-sm">{selectedBooking.admin_notes}</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 取消确认对话框 */}
      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认取消预定</DialogTitle>
            <DialogDescription>
              确定要取消以下预定吗？
            </DialogDescription>
          </DialogHeader>
          
          {bookingToCancel && (
            <div className="space-y-2 py-4">
              <div className="flex items-center gap-2 text-sm">
                <Building2 className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">场地：</span>
                <span>{bookingToCancel.venue?.name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">日期：</span>
                <span>{format(new Date(bookingToCancel.booking_date), 'yyyy-MM-dd', { locale: zhCN })}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">时间：</span>
                <span>
                  {bookingToCancel.start_time.substring(0, 5)} - {bookingToCancel.end_time.substring(0, 5)}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">费用：</span>
                <span>¥{bookingToCancel.final_price}</span>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelDialogOpen(false)}>
              返回
            </Button>
            <Button variant="destructive" onClick={handleCancel}>
              确认取消
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
