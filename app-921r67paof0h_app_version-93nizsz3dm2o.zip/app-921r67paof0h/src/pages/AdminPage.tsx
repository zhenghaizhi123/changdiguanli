import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Users, Shield, User, UserPlus, KeyRound, Trash2, RotateCcw } from 'lucide-react';
import { getAllUsers, updateUserRole } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import type { Profile, UserRole } from '@/types';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const createUserSchema = z.object({
  username: z.string()
    .min(3, '用户名至少3个字符')
    .max(20, '用户名最多20个字符')
    .regex(/^[a-zA-Z0-9_]+$/, '用户名只能包含字母、数字和下划线'),
  password: z.string().min(6, '密码至少6个字符'),
  role: z.enum(['user', 'admin'], { required_error: '请选择用户角色' }),
});

const changePasswordSchema = z.object({
  newPassword: z.string().min(6, '密码至少6个字符'),
  confirmPassword: z.string().min(6, '密码至少6个字符'),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: '两次输入的密码不一致',
  path: ['confirmPassword'],
});

type CreateUserFormData = z.infer<typeof createUserSchema>;
type ChangePasswordFormData = z.infer<typeof changePasswordSchema>;

export default function AdminPage() {
  const { profile: currentProfile, refreshProfile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [newRole, setNewRole] = useState<UserRole>('user');
  const [creating, setCreating] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const form = useForm<CreateUserFormData>({
    resolver: zodResolver(createUserSchema),
    defaultValues: {
      username: '',
      password: '',
      role: 'user',
    },
  });

  const passwordForm = useForm<ChangePasswordFormData>({
    resolver: zodResolver(changePasswordSchema),
    defaultValues: {
      newPassword: '',
      confirmPassword: '',
    },
  });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await getAllUsers();
      setUsers(data);
    } catch (error) {
      toast.error('加载用户列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (user: Profile) => {
    setSelectedUser(user);
    setNewRole(user.role);
    setDialogOpen(true);
  };

  const handleUpdateRole = async () => {
    if (!selectedUser) return;
    
    try {
      await updateUserRole(selectedUser.id, newRole);
      toast.success('用户角色更新成功');
      setDialogOpen(false);
      setSelectedUser(null);
      loadUsers();
      
      // 如果修改的是当前用户，刷新个人信息
      if (selectedUser.id === currentProfile?.id) {
        await refreshProfile();
      }
    } catch (error) {
      toast.error('更新用户角色失败');
    }
  };

  const handleCreateUser = async (data: CreateUserFormData) => {
    try {
      setCreating(true);
      
      // 调用Edge Function创建用户
      const { data: result, error } = await supabase.functions.invoke('create-user', {
        body: {
          username: data.username,
          password: data.password,
          role: data.role,
        },
      });

      if (error) {
        const errorText = error.context?.text ? await error.context.text() : error.message;
        let errorMessage = '创建用户失败';
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        toast.error(errorMessage);
        return;
      }

      if (!result?.success) {
        toast.error(result?.error || '创建用户失败');
        return;
      }

      toast.success('用户创建成功');
      setCreateDialogOpen(false);
      form.reset();
      loadUsers();
    } catch (error) {
      console.error('创建用户失败:', error);
      toast.error('创建用户失败');
    } finally {
      setCreating(false);
    }
  };

  const handleOpenPasswordDialog = (user: Profile) => {
    setSelectedUser(user);
    passwordForm.reset();
    setPasswordDialogOpen(true);
  };

  const handleResetPassword = async (user: Profile) => {
    try {
      setChangingPassword(true);
      
      const defaultPassword = '123456';
      
      // 调用Edge Function修改密码
      const { data: result, error } = await supabase.functions.invoke('change-user-password', {
        body: {
          userId: user.id,
          newPassword: defaultPassword,
        },
      });

      if (error) {
        const errorText = error.context?.text ? await error.context.text() : error.message;
        let errorMessage = '重置密码失败';
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        toast.error(errorMessage);
        return;
      }

      if (!result?.success) {
        toast.error(result?.error || '重置密码失败');
        return;
      }

      toast.success(`用户 ${user.username} 的密码已重置为：${defaultPassword}`);
    } catch (error) {
      console.error('重置密码失败:', error);
      toast.error('重置密码失败');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleChangePassword = async (data: ChangePasswordFormData) => {
    if (!selectedUser) return;
    
    try {
      setChangingPassword(true);
      
      // 调用Edge Function修改密码
      const { data: result, error } = await supabase.functions.invoke('change-user-password', {
        body: {
          userId: selectedUser.id,
          newPassword: data.newPassword,
        },
      });

      if (error) {
        const errorText = error.context?.text ? await error.context.text() : error.message;
        let errorMessage = '修改密码失败';
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        toast.error(errorMessage);
        return;
      }

      if (!result?.success) {
        toast.error(result?.error || '修改密码失败');
        return;
      }

      toast.success('密码修改成功');
      setPasswordDialogOpen(false);
      setSelectedUser(null);
      passwordForm.reset();
    } catch (error) {
      console.error('修改密码失败:', error);
      toast.error('修改密码失败');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleOpenDeleteDialog = (user: Profile) => {
    setSelectedUser(user);
    setDeleteDialogOpen(true);
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      setDeleting(true);
      
      // 调用Edge Function删除用户
      const { data: result, error } = await supabase.functions.invoke('delete-user', {
        body: {
          userId: selectedUser.id,
        },
      });

      if (error) {
        const errorText = error.context?.text ? await error.context.text() : error.message;
        let errorMessage = '删除用户失败';
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }
        toast.error(errorMessage);
        return;
      }

      if (!result?.success) {
        toast.error(result?.error || '删除用户失败');
        return;
      }

      toast.success('用户删除成功');
      setDeleteDialogOpen(false);
      setSelectedUser(null);
      loadUsers();
    } catch (error) {
      console.error('删除用户失败:', error);
      toast.error('删除用户失败');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const adminCount = users.filter(u => u.role === 'admin').length;
  const userCount = users.filter(u => u.role === 'user').length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">用户管理</h1>
        <p className="text-muted-foreground mt-2">管理系统用户和权限</p>
      </div>

      <div className="grid gap-4 xl:grid-cols-3 grid-cols-1">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">总用户数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">管理员</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{adminCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">普通用户</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>用户列表</CardTitle>
              <CardDescription>共 {users.length} 个用户</CardDescription>
            </div>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              创建用户
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>用户名</TableHead>
                  <TableHead>邮箱</TableHead>
                  <TableHead>电话</TableHead>
                  <TableHead>角色</TableHead>
                  <TableHead>注册时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      {user.username}
                      {user.id === currentProfile?.id && (
                        <Badge variant="outline" className="ml-2">当前用户</Badge>
                      )}
                    </TableCell>
                    <TableCell>{user.email || '-'}</TableCell>
                    <TableCell>{user.phone || '-'}</TableCell>
                    <TableCell>
                      <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                        {user.role === 'admin' ? '管理员' : '普通用户'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {format(new Date(user.created_at), 'yyyy-MM-dd', { locale: zhCN })}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 flex-wrap">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenDialog(user)}
                        >
                          修改角色
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenPasswordDialog(user)}
                        >
                          <KeyRound className="h-4 w-4 mr-1" />
                          改密码
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleResetPassword(user)}
                          disabled={changingPassword}
                        >
                          <RotateCcw className="h-4 w-4 mr-1" />
                          重置密码
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenDeleteDialog(user)}
                          disabled={user.id === currentProfile?.id}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          删除
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* 修改角色对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>修改用户角色</DialogTitle>
            <DialogDescription>
              修改用户 {selectedUser?.username} 的角色
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>当前角色</Label>
              <div>
                <Badge variant={selectedUser?.role === 'admin' ? 'default' : 'secondary'}>
                  {selectedUser?.role === 'admin' ? '管理员' : '普通用户'}
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <Label>新角色</Label>
              <Select value={newRole} onValueChange={(value) => setNewRole(value as UserRole)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">普通用户</SelectItem>
                  <SelectItem value="admin">管理员</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedUser?.id === currentProfile?.id && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  ⚠️ 您正在修改自己的角色，修改后可能会失去管理员权限
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleUpdateRole}>
              确认修改
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 创建用户对话框 */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>创建新用户</DialogTitle>
            <DialogDescription>
              手动创建用户账号并设置初始密码
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateUser)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>用户名</FormLabel>
                    <FormControl>
                      <Input placeholder="输入用户名（字母、数字、下划线）" {...field} disabled={creating} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>初始密码</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="至少6个字符" {...field} disabled={creating} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>用户角色</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={creating}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="选择用户角色" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="user">普通用户</SelectItem>
                        <SelectItem value="admin">管理员</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCreateDialogOpen(false)} disabled={creating}>
                  取消
                </Button>
                <Button type="submit" disabled={creating}>
                  {creating ? '创建中...' : '创建用户'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* 修改密码对话框 */}
      <Dialog open={passwordDialogOpen} onOpenChange={setPasswordDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>修改用户密码</DialogTitle>
            <DialogDescription>
              为用户 {selectedUser?.username} 设置新密码
            </DialogDescription>
          </DialogHeader>
          
          <Form {...passwordForm}>
            <form onSubmit={passwordForm.handleSubmit(handleChangePassword)} className="space-y-4">
              <FormField
                control={passwordForm.control}
                name="newPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>新密码</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="至少6个字符" 
                        {...field} 
                        disabled={changingPassword}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={passwordForm.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>确认密码</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="再次输入新密码" 
                        {...field} 
                        disabled={changingPassword}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setPasswordDialogOpen(false)} 
                  disabled={changingPassword}
                >
                  取消
                </Button>
                <Button type="submit" disabled={changingPassword}>
                  {changingPassword ? '修改中...' : '确认修改'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* 删除用户确认对话框 */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认删除用户</DialogTitle>
            <DialogDescription>
              您确定要删除用户 <span className="font-semibold text-foreground">{selectedUser?.username}</span> 吗？
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
              <p className="font-semibold mb-2">⚠️ 警告：此操作不可撤销</p>
              <ul className="list-disc list-inside space-y-1">
                <li>用户账号将被永久删除</li>
                <li>用户将无法再登录系统</li>
                <li>用户的预定记录会保留在系统中</li>
              </ul>
            </div>

            {selectedUser?.id === currentProfile?.id && (
              <div className="rounded-lg bg-yellow-500/10 p-4 text-sm text-yellow-600 dark:text-yellow-500">
                <p className="font-semibold">⚠️ 您不能删除自己的账号</p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setDeleteDialogOpen(false)} 
              disabled={deleting}
            >
              取消
            </Button>
            <Button 
              type="button"
              variant="destructive"
              onClick={handleDeleteUser}
              disabled={deleting || selectedUser?.id === currentProfile?.id}
            >
              {deleting ? '删除中...' : '确认删除'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
