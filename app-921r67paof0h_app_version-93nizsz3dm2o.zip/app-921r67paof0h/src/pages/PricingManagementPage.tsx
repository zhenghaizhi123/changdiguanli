import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DollarSign, Building2, Save, X, Pencil } from 'lucide-react';
import { getVenues, updateVenue } from '@/db/api';
import type { Venue } from '@/types';
import { toast } from 'sonner';

export default function PricingManagementPage() {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState<{ half_day: string; full_day: string }>({ half_day: '', full_day: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadVenues();
  }, []);

  const loadVenues = async () => {
    try {
      setLoading(true);
      const data = await getVenues();
      setVenues(data);
    } catch (error) {
      toast.error('加载场地列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (venue: Venue) => {
    setEditingId(venue.id);
    setEditData({
      half_day: venue.half_day_price.toString(),
      full_day: venue.full_day_price.toString(),
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditData({ half_day: '', full_day: '' });
  };

  const handleSave = async (venueId: string) => {
    const halfDayPrice = Number.parseFloat(editData.half_day);
    const fullDayPrice = Number.parseFloat(editData.full_day);
    
    if (Number.isNaN(halfDayPrice) || Number.isNaN(fullDayPrice)) {
      toast.error('请输入有效的价格');
      return;
    }
    
    if (halfDayPrice < 0 || fullDayPrice < 0) {
      toast.error('价格不能为负数');
      return;
    }
    
    try {
      setSaving(true);
      await updateVenue(venueId, {
        half_day_price: halfDayPrice,
        full_day_price: fullDayPrice,
      });
      toast.success('价格更新成功');
      setEditingId(null);
      loadVenues();
    } catch (error) {
      toast.error('更新价格失败');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">费用管理</h1>
        <p className="text-muted-foreground mt-2">管理所有场地的预定费用</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            场地价格列表
          </CardTitle>
          <CardDescription>点击编辑按钮修改场地价格</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>场地名称</TableHead>
                <TableHead>类型</TableHead>
                <TableHead>位置</TableHead>
                <TableHead>半天价格（元）</TableHead>
                <TableHead>全天价格（元）</TableHead>
                <TableHead>状态</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {venues.map((venue) => (
                <TableRow key={venue.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-muted-foreground" />
                      {venue.name}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{venue.type}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{venue.location}</TableCell>
                  <TableCell>
                    {editingId === venue.id ? (
                      <Input
                        type="number"
                        step="0.01"
                        value={editData.half_day}
                        onChange={(e) => setEditData({ ...editData, half_day: e.target.value })}
                        className="w-24"
                        disabled={saving}
                      />
                    ) : (
                      <span>¥{venue.half_day_price}</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {editingId === venue.id ? (
                      <Input
                        type="number"
                        step="0.01"
                        value={editData.full_day}
                        onChange={(e) => setEditData({ ...editData, full_day: e.target.value })}
                        className="w-24"
                        disabled={saving}
                      />
                    ) : (
                      <span>¥{venue.full_day_price}</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={venue.is_active ? 'default' : 'secondary'}>
                      {venue.is_active ? '启用' : '禁用'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    {editingId === venue.id ? (
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleSave(venue.id)}
                          disabled={saving}
                        >
                          <Save className="h-4 w-4 mr-1" />
                          保存
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleCancel}
                          disabled={saving}
                        >
                          <X className="h-4 w-4 mr-1" />
                          取消
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(venue)}
                      >
                        <Pencil className="h-4 w-4 mr-1" />
                        编辑
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {venues.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              暂无场地数据
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>说明</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• 每个场地可以设置独立的半天和全天价格</p>
          <p>• 价格修改后立即生效，影响新的预定申请</p>
          <p>• 已提交的预定不受价格调整影响</p>
          <p>• 管理员可以在预定管理页面对单个预定进行人工改价</p>
        </CardContent>
      </Card>
    </div>
  );
}
