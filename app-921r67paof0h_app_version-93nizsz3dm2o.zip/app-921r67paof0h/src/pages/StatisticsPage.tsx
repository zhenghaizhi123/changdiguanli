import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, Building2, TrendingUp, DollarSign, CalendarIcon, MapPin } from 'lucide-react';
import { getOrganizationStats, getOrganizationList, getUserBookings, getVenueStats } from '@/db/api';
import type { OrganizationStats, VenueStats } from '@/db/api';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { cn } from '@/lib/utils';

type TimeRangeType = 'year' | 'month' | 'custom';
type StatType = 'organization' | 'venue';

export default function StatisticsPage() {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  
  const [statType, setStatType] = useState<StatType>('organization');
  const [stats, setStats] = useState<OrganizationStats[]>([]);
  const [venueStats, setVenueStats] = useState<VenueStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRangeType, setTimeRangeType] = useState<TimeRangeType>('year');
  const [selectedYear, setSelectedYear] = useState<string>(new Date().getFullYear().toString());
  const [selectedMonth, setSelectedMonth] = useState<string>((new Date().getMonth() + 1).toString());
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [selectedOrg, setSelectedOrg] = useState<string>('all');
  const [orgList, setOrgList] = useState<string[]>([]);
  const [userOrg, setUserOrg] = useState<string>('');

  // 生成年份列表（最近5年）
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);
  
  // 生成月份列表
  const months = Array.from({ length: 12 }, (_, i) => i + 1);

  useEffect(() => {
    if (isAdmin) {
      loadOrganizationList();
    } else {
      // 普通用户：获取自己的单位名称
      loadUserOrganization();
    }
  }, [isAdmin]);

  useEffect(() => {
    if (statType === 'organization') {
      loadStats();
    } else {
      loadVenueStats();
    }
  }, [timeRangeType, selectedYear, selectedMonth, startDate, endDate, selectedOrg, userOrg, isAdmin, statType]);

  const loadOrganizationList = async () => {
    try {
      const list = await getOrganizationList();
      setOrgList(list);
    } catch (error) {
      console.error('加载单位列表失败:', error);
    }
  };

  const loadUserOrganization = async () => {
    if (!profile) return;
    
    try {
      // 获取用户的预定记录，从中提取单位名称
      const bookings = await getUserBookings(profile.id);
      const userBooking = bookings.find(b => b.organization_name);
      if (userBooking?.organization_name) {
        setUserOrg(userBooking.organization_name);
      }
    } catch (error) {
      console.error('加载用户单位失败:', error);
    }
  };

  const loadStats = async () => {
    try {
      setLoading(true);
      
      let year: number | undefined;
      let dateStart: string | undefined;
      let dateEnd: string | undefined;
      
      // 根据时间范围类型计算日期范围
      if (timeRangeType === 'year') {
        year = Number.parseInt(selectedYear);
      } else if (timeRangeType === 'month') {
        const monthDate = new Date(Number.parseInt(selectedYear), Number.parseInt(selectedMonth) - 1, 1);
        dateStart = format(startOfMonth(monthDate), 'yyyy-MM-dd');
        dateEnd = format(endOfMonth(monthDate), 'yyyy-MM-dd');
      } else if (timeRangeType === 'custom') {
        if (startDate && endDate) {
          dateStart = format(startDate, 'yyyy-MM-dd');
          dateEnd = format(endDate, 'yyyy-MM-dd');
        }
      }
      
      let organizationName: string | undefined;
      if (isAdmin) {
        // 管理员：根据选择的单位筛选
        organizationName = selectedOrg === 'all' ? undefined : selectedOrg;
      } else {
        // 普通用户：只能看自己的单位
        organizationName = userOrg || undefined;
      }
      
      const data = await getOrganizationStats(organizationName, year, dateStart, dateEnd);
      setStats(data);
    } catch (error) {
      toast.error('加载统计数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadVenueStats = async () => {
    try {
      setLoading(true);
      
      let dateStart: string | undefined;
      let dateEnd: string | undefined;
      
      // 根据时间范围类型计算日期范围
      if (timeRangeType === 'year') {
        const year = Number.parseInt(selectedYear);
        dateStart = `${year}-01-01`;
        dateEnd = `${year}-12-31`;
      } else if (timeRangeType === 'month') {
        const monthDate = new Date(Number.parseInt(selectedYear), Number.parseInt(selectedMonth) - 1, 1);
        dateStart = format(startOfMonth(monthDate), 'yyyy-MM-dd');
        dateEnd = format(endOfMonth(monthDate), 'yyyy-MM-dd');
      } else if (timeRangeType === 'custom') {
        if (startDate && endDate) {
          dateStart = format(startDate, 'yyyy-MM-dd');
          dateEnd = format(endDate, 'yyyy-MM-dd');
        }
      }
      
      // 确定单位筛选参数
      let organizationName: string | undefined;
      if (isAdmin) {
        // 管理员：根据选择的单位筛选
        organizationName = selectedOrg === 'all' ? undefined : selectedOrg;
      } else {
        // 普通用户：只能看自己的单位
        organizationName = userOrg || undefined;
      }
      
      const data = await getVenueStats(dateStart, dateEnd, organizationName);
      setVenueStats(data);
    } catch (error) {
      toast.error('加载场地统计数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const exportData = stats.map((stat) => ({
      单位名称: stat.organization_name,
      使用次数: stat.booking_count,
      总费用: stat.total_amount,
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '单位统计');
    
    let timeSuffix = '';
    if (timeRangeType === 'year') {
      timeSuffix = `${selectedYear}年`;
    } else if (timeRangeType === 'month') {
      timeSuffix = `${selectedYear}年${selectedMonth}月`;
    } else if (timeRangeType === 'custom' && startDate && endDate) {
      timeSuffix = `${format(startDate, 'yyyyMMdd')}-${format(endDate, 'yyyyMMdd')}`;
    }
    
    const fileName = `单位使用统计_${timeSuffix}_${format(new Date(), 'yyyyMMdd_HHmmss')}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast.success('导出成功');
  };

  const handleExportVenue = () => {
    const exportData = venueStats.map((stat) => ({
      场地名称: stat.venue_name,
      场地类型: stat.venue_type,
      容纳人数: stat.capacity,
      位置: stat.location,
      预约次数: stat.booking_count,
      总收入: stat.total_amount.toFixed(2),
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '场地统计');
    
    let timeSuffix = '';
    if (timeRangeType === 'year') {
      timeSuffix = `${selectedYear}年`;
    } else if (timeRangeType === 'month') {
      timeSuffix = `${selectedYear}年${selectedMonth}月`;
    } else if (timeRangeType === 'custom' && startDate && endDate) {
      timeSuffix = `${format(startDate, 'yyyyMMdd')}-${format(endDate, 'yyyyMMdd')}`;
    }
    
    const fileName = `场地统计_${timeSuffix}_${format(new Date(), 'yyyyMMdd_HHmmss')}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    toast.success('场地信息导出成功');
  };

  // 计算总计
  const totalBookings = stats.reduce((sum, stat) => sum + stat.booking_count, 0);
  const totalAmount = stats.reduce((sum, stat) => sum + stat.total_amount, 0);
  
  // 场地统计总计
  const totalVenueBookings = venueStats.reduce((sum, stat) => sum + stat.booking_count, 0);
  const totalVenueAmount = venueStats.reduce((sum, stat) => sum + stat.total_amount, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">数据统计</h1>
          <p className="text-muted-foreground mt-2">
            {statType === 'organization' 
              ? (isAdmin ? '查看所有单位的场地使用情况' : '查看本单位的场地使用情况')
              : '查看所有场地的使用情况和收入统计'}
          </p>
        </div>
        <Button 
          onClick={statType === 'organization' ? handleExport : handleExportVenue} 
          disabled={statType === 'organization' ? stats.length === 0 : venueStats.length === 0}
        >
          <Download className="mr-2 h-4 w-4" />
          {statType === 'organization' ? '导出单位统计' : '导出场地信息'}
        </Button>
      </div>

      {/* 统计类型切换 */}
      <Tabs value={statType} onValueChange={(value) => setStatType(value as StatType)}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="organization">单位统计</TabsTrigger>
          <TabsTrigger value="venue">场地统计</TabsTrigger>
        </TabsList>

        {/* 单位统计 */}
        <TabsContent value="organization" className="space-y-6">
          {/* 统计卡片 */}
          <div className="grid gap-4 xl:grid-cols-3 grid-cols-1">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  统计单位数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  总使用次数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalBookings}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  总费用金额
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">¥{totalAmount.toFixed(2)}</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* 场地统计 */}
        <TabsContent value="venue" className="space-y-6">
          {/* 统计卡片 */}
          <div className="grid gap-4 xl:grid-cols-3 grid-cols-1">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  场地总数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{venueStats.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  总预约次数
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalVenueBookings}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  总收入金额
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">¥{totalVenueAmount.toFixed(2)}</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* 筛选条件 */}
      <Card>
        <CardHeader>
          <CardTitle>筛选条件</CardTitle>
          <CardDescription>
            选择时间范围{isAdmin ? '和单位' : ''}查看统计数据
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* 时间范围类型选择 */}
            <div className="space-y-2">
              <label className="text-sm font-medium">统计范围</label>
              <Select value={timeRangeType} onValueChange={(value: TimeRangeType) => setTimeRangeType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="year">按年度</SelectItem>
                  <SelectItem value="month">按月度</SelectItem>
                  <SelectItem value="custom">自定义时间段</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 年度选择 */}
            {timeRangeType === 'year' && (
              <div className="space-y-2">
                <label className="text-sm font-medium">选择年度</label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((year) => (
                      <SelectItem key={year} value={year.toString()}>
                        {year}年
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* 月度选择 */}
            {timeRangeType === 'month' && (
              <div className="grid gap-4 xl:grid-cols-2 grid-cols-1">
                <div className="space-y-2">
                  <label className="text-sm font-medium">选择年份</label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}年
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">选择月份</label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map((month) => (
                        <SelectItem key={month} value={month.toString()}>
                          {month}月
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* 自定义时间段选择 */}
            {timeRangeType === 'custom' && (
              <div className="grid gap-4 xl:grid-cols-2 grid-cols-1">
                <div className="space-y-2">
                  <label className="text-sm font-medium">开始日期</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          'w-full justify-start text-left font-normal',
                          !startDate && 'text-muted-foreground'
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, 'yyyy年MM月dd日', { locale: zhCN }) : '选择开始日期'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">结束日期</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          'w-full justify-start text-left font-normal',
                          !endDate && 'text-muted-foreground'
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {endDate ? format(endDate, 'yyyy年MM月dd日', { locale: zhCN }) : '选择结束日期'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            )}
            
            {/* 单位选择（管理员可选，场地统计时也显示） */}
            {isAdmin && (
              <div className="space-y-2">
                <label className="text-sm font-medium">选择单位</label>
                <Select value={selectedOrg} onValueChange={setSelectedOrg}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部单位</SelectItem>
                    {orgList.map((org) => (
                      <SelectItem key={org} value={org}>
                        {org}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 统计表格 */}
      <Card>
        <CardHeader>
          <CardTitle>统计详情</CardTitle>
          <CardDescription>
            {statType === 'organization' ? '单位使用统计详情' : '场地使用统计详情'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            {statType === 'organization' ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>排名</TableHead>
                    <TableHead>单位名称</TableHead>
                    <TableHead>使用次数</TableHead>
                    <TableHead>总费用</TableHead>
                    <TableHead>平均费用</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.map((stat, index) => (
                    <TableRow key={stat.organization_name}>
                      <TableCell>
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted font-bold">
                          {index + 1}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{stat.organization_name}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{stat.booking_count} 次</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">¥{stat.total_amount.toFixed(2)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">
                          ¥{(stat.total_amount / stat.booking_count).toFixed(2)}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>排名</TableHead>
                    <TableHead>场地名称</TableHead>
                    <TableHead>场地类型</TableHead>
                    <TableHead>容纳人数</TableHead>
                    <TableHead>位置</TableHead>
                    <TableHead>预约次数</TableHead>
                    <TableHead>总收入</TableHead>
                    <TableHead>平均收入</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {venueStats.map((stat, index) => (
                    <TableRow key={stat.venue_id}>
                      <TableCell>
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted font-bold">
                          {index + 1}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{stat.venue_name}</div>
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">{stat.venue_type}</span>
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">{stat.capacity}人</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground text-sm">{stat.location}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{stat.booking_count} 次</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">¥{stat.total_amount.toFixed(2)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">
                          {stat.booking_count > 0 
                            ? `¥${(stat.total_amount / stat.booking_count).toFixed(2)}`
                            : '-'}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            {statType === 'organization' && stats.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                {isAdmin 
                  ? '暂无统计数据' 
                  : userOrg 
                    ? '本单位暂无预定记录' 
                    : '您还没有以单位名义进行过预定'}
              </div>
            )}
            
            {statType === 'venue' && venueStats.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                暂无场地数据
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
