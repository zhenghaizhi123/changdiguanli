import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Building2, MapPin, Users, Plus, Pencil, Trash2 } from 'lucide-react';
import { getVenues, createVenue, updateVenue, deleteVenue } from '@/db/api';
import type { Venue, VenueType } from '@/types';
import { toast } from 'sonner';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const venueSchema = z.object({
  name: z.string().min(1, '请输入场地名称'),
  type: z.string().min(1, '请输入场地类型'),
  capacity: z.coerce.number().min(1, '容量必须大于0'),
  location: z.string().min(1, '请输入场地位置'),
  description: z.string().optional(),
  half_day_price: z.coerce.number().min(0, '半天价格不能为负数'),
  full_day_price: z.coerce.number().min(0, '全天价格不能为负数'),
});

type VenueFormData = z.infer<typeof venueSchema>;

export default function VenuesPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [venues, setVenues] = useState<Venue[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingVenue, setEditingVenue] = useState<Venue | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [venueToDelete, setVenueToDelete] = useState<Venue | null>(null);
  
  const isAdmin = profile?.role === 'admin';

  const form = useForm<VenueFormData>({
    resolver: zodResolver(venueSchema),
    defaultValues: {
      name: '',
      type: '教室',
      capacity: 50,
      location: '',
      description: '',
      half_day_price: 500,
      full_day_price: 1000,
    },
  });

  useEffect(() => {
    loadVenues();
  }, []);

  const loadVenues = async () => {
    try {
      setLoading(true);
      const data = await getVenues();
      setVenues(data);
    } catch (error) {
      toast.error('加载场地列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (venue?: Venue) => {
    if (venue) {
      setEditingVenue(venue);
      form.reset({
        name: venue.name,
        type: venue.type,
        capacity: venue.capacity,
        location: venue.location,
        description: venue.description || '',
        half_day_price: venue.half_day_price,
        full_day_price: venue.full_day_price,
      });
    } else {
      setEditingVenue(null);
      form.reset({
        name: '',
        type: '教室',
        capacity: 50,
        location: '',
        description: '',
        half_day_price: 500,
        full_day_price: 1000,
      });
    }
    setDialogOpen(true);
  };

  const handleSubmit = async (data: VenueFormData) => {
    try {
      if (editingVenue) {
        await updateVenue(editingVenue.id, {
          ...data,
          description: data.description || null,
        });
        toast.success('场地更新成功');
      } else {
        await createVenue({
          ...data,
          description: data.description || null,
          is_active: true,
        });
        toast.success('场地创建成功');
      }
      setDialogOpen(false);
      loadVenues();
    } catch (error) {
      toast.error(editingVenue ? '更新场地失败' : '创建场地失败');
    }
  };

  const handleDelete = async () => {
    if (!venueToDelete) return;
    
    try {
      await deleteVenue(venueToDelete.id);
      toast.success('场地删除成功');
      setDeleteDialogOpen(false);
      setVenueToDelete(null);
      loadVenues();
    } catch (error) {
      toast.error('删除场地失败');
    }
  };

  const handleToggleActive = async (venue: Venue) => {
    try {
      await updateVenue(venue.id, { is_active: !venue.is_active });
      toast.success(venue.is_active ? '场地已禁用' : '场地已启用');
      loadVenues();
    } catch (error) {
      toast.error('操作失败');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">场地{isAdmin ? '管理' : '列表'}</h1>
          <p className="text-muted-foreground mt-2">
            {isAdmin ? '管理所有场地信息' : '浏览可预定的场地'}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => navigate('/venue-schedule')}
          >
            <Building2 className="mr-2 h-4 w-4" />
            可视化预约
          </Button>
          {isAdmin && (
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="mr-2 h-4 w-4" />
              添加场地
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-3 grid-cols-1 @container">
        {venues.map((venue) => (
          <Card key={venue.id} className={!venue.is_active ? 'opacity-60' : ''}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    {venue.name}
                  </CardTitle>
                  <CardDescription className="mt-2">
                    <Badge variant="secondary">{venue.type}</Badge>
                    {!venue.is_active && (
                      <Badge variant="outline" className="ml-2">已禁用</Badge>
                    )}
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center text-sm text-muted-foreground">
                <MapPin className="mr-2 h-4 w-4" />
                {venue.location}
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Users className="mr-2 h-4 w-4" />
                容量：{venue.capacity}人
              </div>
              {venue.description && (
                <p className="text-sm text-muted-foreground">{venue.description}</p>
              )}
              
              <div className="flex gap-2 pt-2">
                {isAdmin ? (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenDialog(venue)}
                    >
                      <Pencil className="mr-2 h-4 w-4" />
                      编辑
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleToggleActive(venue)}
                    >
                      {venue.is_active ? '禁用' : '启用'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setVenueToDelete(venue);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      删除
                    </Button>
                  </>
                ) : (
                  venue.is_active && (
                    <Button
                      className="w-full"
                      onClick={() => navigate(`/venues/${venue.id}`)}
                    >
                      预定场地
                    </Button>
                  )
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {venues.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Building2 className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">暂无场地</p>
          </CardContent>
        </Card>
      )}

      {/* 添加/编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingVenue ? '编辑场地' : '添加场地'}</DialogTitle>
            <DialogDescription>
              {editingVenue ? '修改场地信息' : '填写场地基本信息'}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>场地名称</FormLabel>
                    <FormControl>
                      <Input placeholder="例如：第一教室" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>场地类型</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="例如：教室、招聘大厅、会议室、培训室、展厅等" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="capacity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>容量（人）</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="50" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>位置</FormLabel>
                    <FormControl>
                      <Input placeholder="例如：一楼东侧" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>描述（可选）</FormLabel>
                    <FormControl>
                      <Textarea placeholder="场地的详细描述" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="half_day_price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>半天价格（元）</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="500" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="full_day_price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>全天价格（元）</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="1000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  取消
                </Button>
                <Button type="submit">
                  {editingVenue ? '保存' : '创建'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>
              确定要删除场地"{venueToDelete?.name}"吗？此操作无法撤销。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
