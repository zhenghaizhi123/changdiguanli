import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { format, addDays } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { getVenues, getAllBookings } from '@/db/api';
import type { Venue, BookingDetail } from '@/types';

export default function VenueSchedulePage() {
  const navigate = useNavigate();
  const [venues, setVenues] = useState<Venue[]>([]);
  const [bookings, setBookings] = useState<BookingDetail[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  // 获取本周日期（从今天开始的7天）
  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(selectedDate, i));

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [venuesData, bookingsData] = await Promise.all([
        getVenues(),
        getAllBookings()
      ]);
      setVenues(venuesData);
      setBookings(bookingsData);
    } catch (error) {
      console.error('加载数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  // 过滤场地
  const filteredVenues = venues.filter(venue =>
    venue.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    venue.type.includes(searchQuery)
  );

  // 按类型分组场地
  const venuesByType = filteredVenues.reduce((acc, venue) => {
    const type = venue.type;
    if (!acc[type]) {
      acc[type] = [];
    }
    acc[type].push(venue);
    return acc;
  }, {} as Record<string, Venue[]>);

  // 获取某个场地在某个日期的预约情况
  const getVenueBookingsForDate = (venueId: string, date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return bookings.filter(
      b => b.venue_id === venueId && 
           b.booking_date === dateStr && 
           b.status === 'approved'
    );
  };

  // 渲染时间轴
  const renderTimeline = (venueId: string, date: Date) => {
    const venueBookings = getVenueBookingsForDate(venueId, date);
    const hours = Array.from({ length: 13 }, (_, i) => i + 8); // 8:00 - 20:00

    return (
      <div className="flex items-center gap-0.5">
        {hours.map((hour) => {
          // 检查这个小时是否被预约
          const isBooked = venueBookings.some(booking => {
            const startHour = parseInt(booking.start_time.substring(0, 2));
            const endHour = parseInt(booking.end_time.substring(0, 2));
            return hour >= startHour && hour < endHour;
          });

          return (
            <div
              key={hour}
              className={`h-6 flex-1 rounded-sm ${
                isBooked
                  ? 'bg-red-400'
                  : 'bg-green-200'
              }`}
              title={`${hour}:00`}
            />
          );
        })}
      </div>
    );
  };

  // 切换到上一周
  const handlePrevWeek = () => {
    setSelectedDate(addDays(selectedDate, -7));
  };

  // 切换到下一周
  const handleNextWeek = () => {
    setSelectedDate(addDays(selectedDate, 7));
  };

  // 跳转到场地详情页
  const handleVenueClick = (venueId: string) => {
    navigate(`/venues/${venueId}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="text-lg">加载中...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 xl:p-6 space-y-4">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl xl:text-3xl font-bold">多场地占用可视化</h1>
          <p className="text-sm text-muted-foreground mt-1">
            查看所有场地的预约情况，快速选择可用时段
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => navigate('/venues')}
        >
          返回场地列表
        </Button>
      </div>

      <Separator />

      {/* 搜索和日期选择 */}
      <div className="flex flex-col xl:flex-row gap-4">
        {/* 搜索框 */}
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="输入关键词搜索场地..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* 日期导航 */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePrevWeek}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2 px-4 py-2 border rounded-md bg-background">
            <CalendarIcon className="h-4 w-4" />
            <span className="text-sm font-medium">
              {format(weekDates[0], 'MM月dd日', { locale: zhCN })} - {format(weekDates[6], 'MM月dd日', { locale: zhCN })}
            </span>
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={handleNextWeek}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* 日期标签 */}
      <div className="grid grid-cols-7 gap-2">
        {weekDates.map((date, index) => (
          <div
            key={index}
            className="text-center p-2 rounded-md bg-muted/50"
          >
            <div className="text-xs text-muted-foreground">
              {format(date, 'EEEE', { locale: zhCN })}
            </div>
            <div className="text-sm font-medium">
              {format(date, 'MM/dd', { locale: zhCN })}
            </div>
          </div>
        ))}
      </div>

      {/* 时间轴标签 */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground px-4">
        <div className="w-48 shrink-0"></div>
        <div className="flex-1 flex justify-between">
          {Array.from({ length: 13 }, (_, i) => i + 8).map((hour) => (
            <span key={hour}>{hour}</span>
          ))}
        </div>
        <div className="w-20 shrink-0"></div>
      </div>

      {/* 场地列表 */}
      <div className="space-y-6">
        {Object.entries(venuesByType).map(([type, typeVenues]) => (
          <div key={type} className="space-y-3">
            {/* 类型标题 */}
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-sm">
                {type}
              </Badge>
              <Separator className="flex-1" />
            </div>

            {/* 该类型的所有场地 */}
            {typeVenues.map((venue) => (
              <Card key={venue.id} className="p-4">
                <div className="space-y-3">
                  {/* 场地信息 */}
                  <div className="flex items-center gap-4">
                    <div className="w-48 shrink-0">
                      <div className="font-medium">{venue.name}</div>
                      <div className="text-xs text-muted-foreground">
                        容量: {venue.capacity}人
                      </div>
                    </div>
                    <div className="flex-1 space-y-2">
                      {weekDates.map((date, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-16 text-xs text-muted-foreground shrink-0">
                            {format(date, 'MM/dd', { locale: zhCN })}
                          </div>
                          <div className="flex-1">
                            {renderTimeline(venue.id, date)}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="w-20 shrink-0">
                      <Button
                        size="sm"
                        onClick={() => handleVenueClick(venue.id)}
                      >
                        预约
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ))}
      </div>

      {/* 图例 */}
      <Card className="p-4">
        <div className="flex items-center gap-6 text-sm">
          <div className="font-medium">图例：</div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-4 bg-green-200 rounded-sm"></div>
            <span>可预约</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-4 bg-red-400 rounded-sm"></div>
            <span>已预约</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
