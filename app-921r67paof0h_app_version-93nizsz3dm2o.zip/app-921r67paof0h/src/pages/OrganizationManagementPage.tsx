import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Building, Plus, Pencil, Trash2, Power, PowerOff } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

const organizationSchema = z.object({
  name: z.string().min(1, '请输入单位名称'),
  description: z.string().optional(),
});

type OrganizationFormData = z.infer<typeof organizationSchema>;

interface Organization {
  id: string;
  name: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

export default function OrganizationManagementPage() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOrg, setEditingOrg] = useState<Organization | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<OrganizationFormData>({
    resolver: zodResolver(organizationSchema),
    defaultValues: {
      name: '',
      description: '',
    },
  });

  useEffect(() => {
    loadOrganizations();
  }, []);

  const loadOrganizations = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setOrganizations(data || []);
    } catch (error) {
      console.error('加载单位列表失败:', error);
      toast.error('加载单位列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = () => {
    setEditingOrg(null);
    form.reset({
      name: '',
      description: '',
    });
    setDialogOpen(true);
  };

  const handleEdit = (org: Organization) => {
    setEditingOrg(org);
    form.reset({
      name: org.name,
      description: org.description || '',
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (data: OrganizationFormData) => {
    try {
      setSubmitting(true);
      
      if (editingOrg) {
        // 更新
        const { error } = await supabase
          .from('organizations')
          .update({
            name: data.name,
            description: data.description || null,
            updated_at: new Date().toISOString(),
          } as never)
          .eq('id', editingOrg.id);
        
        if (error) throw error;
        toast.success('单位信息已更新');
      } else {
        // 新增
        const { error } = await supabase
          .from('organizations')
          .insert({
            name: data.name,
            description: data.description || null,
          } as never);
        
        if (error) {
          if (error.code === '23505') {
            toast.error('该单位名称已存在');
            return;
          }
          throw error;
        }
        toast.success('单位已添加');
      }
      
      setDialogOpen(false);
      loadOrganizations();
    } catch (error) {
      console.error('保存单位失败:', error);
      toast.error('保存单位失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (org: Organization) => {
    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          is_active: !org.is_active,
          updated_at: new Date().toISOString(),
        } as never)
        .eq('id', org.id);
      
      if (error) throw error;
      toast.success(org.is_active ? '单位已停用' : '单位已启用');
      loadOrganizations();
    } catch (error) {
      console.error('切换单位状态失败:', error);
      toast.error('操作失败');
    }
  };

  const handleDelete = async (org: Organization) => {
    if (!confirm(`确定要删除单位"${org.name}"吗？此操作不可恢复。`)) {
      return;
    }
    
    try {
      const { error } = await supabase
        .from('organizations')
        .delete()
        .eq('id', org.id);
      
      if (error) throw error;
      toast.success('单位已删除');
      loadOrganizations();
    } catch (error) {
      console.error('删除单位失败:', error);
      toast.error('删除失败');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">单位管理</h1>
          <p className="text-muted-foreground mt-2">管理预约单位列表，方便用户快速选择</p>
        </div>
        <Button onClick={handleAdd}>
          <Plus className="mr-2 h-4 w-4" />
          添加单位
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            单位列表
          </CardTitle>
          <CardDescription>共 {organizations.length} 个单位</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>单位名称</TableHead>
                <TableHead>描述</TableHead>
                <TableHead>状态</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {organizations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    暂无单位数据
                  </TableCell>
                </TableRow>
              ) : (
                organizations.map((org) => (
                  <TableRow key={org.id}>
                    <TableCell className="font-medium">{org.name}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {org.description || '-'}
                    </TableCell>
                    <TableCell>
                      {org.is_active ? (
                        <Badge variant="default">启用</Badge>
                      ) : (
                        <Badge variant="secondary">停用</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(org)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleToggleActive(org)}
                        >
                          {org.is_active ? (
                            <PowerOff className="h-4 w-4" />
                          ) : (
                            <Power className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(org)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* 添加/编辑对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingOrg ? '编辑单位' : '添加单位'}</DialogTitle>
            <DialogDescription>
              {editingOrg ? '修改单位信息' : '添加新的预约单位'}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>单位名称 <span className="text-destructive">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="请输入单位名称" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>描述（可选）</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="请输入单位描述信息" 
                        className="min-h-[80px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  取消
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? '保存中...' : '保存'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
