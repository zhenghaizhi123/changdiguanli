import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Building2, MapPin, Users, ArrowLeft, Calendar as CalendarIcon, Clock, User, Building, AlertCircle, FileSignature, CheckCircle2 } from 'lucide-react';
import { getVenue, checkVenueAvailability, createBooking, getVenueBookingCalendar, getDateBookings } from '@/db/api';
import type { Venue, BookingDuration, BookingDetail } from '@/types';
import { toast } from 'sonner';
import { format, addMonths, startOfMonth, endOfMonth } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/db/supabase';
import { SignaturePad } from '@/components/ui/signature-pad';
import { Alert, AlertDescription } from '@/components/ui/alert';

const bookingSchema = z.object({
  start_time: z.string().min(1, '请选择开始时间'),
  end_time: z.string().min(1, '请选择结束时间'),
  organization_name: z.string().min(1, '请选择或输入预约单位'),
  contact_person: z.string().min(1, '请输入联系人'),
  contact_phone: z.string().min(1, '请输入联系电话'),
  purpose: z.string().min(1, '请输入使用说明'),
}).refine((data) => {
  // 验证结束时间必须晚于开始时间
  return data.end_time > data.start_time;
}, {
  message: '结束时间必须晚于开始时间',
  path: ['end_time'],
});

type BookingFormData = z.infer<typeof bookingSchema>;

// 根据时间跨度计算是半天还是全天
function calculateDuration(startTime: string, endTime: string): BookingDuration {
  const [startHour, startMinute] = startTime.split(':').map(Number);
  const [endHour, endMinute] = endTime.split(':').map(Number);
  
  const startMinutes = startHour * 60 + startMinute;
  const endMinutes = endHour * 60 + endMinute;
  const durationMinutes = endMinutes - startMinutes;
  
  console.log('=== calculateDuration ===');
  console.log('开始时间:', startTime, '=', startMinutes, '分钟');
  console.log('结束时间:', endTime, '=', endMinutes, '分钟');
  console.log('时长:', durationMinutes, '分钟 =', (durationMinutes / 60).toFixed(2), '小时');
  
  // 4小时（240分钟）以内算半天，超过算全天
  const duration = durationMinutes <= 240 ? 'half_day' : 'full_day';
  console.log('判定结果:', duration);
  
  return duration;
}

export default function VenueDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [venue, setVenue] = useState<Venue | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [bookingCalendar, setBookingCalendar] = useState<BookingDetail[]>([]);
  const [selectedDateBookings, setSelectedDateBookings] = useState<BookingDetail[]>([]);
  const [organizations, setOrganizations] = useState<Array<{ id: string; name: string }>>([]);
  const [customOrganization, setCustomOrganization] = useState(false);
  const [dateBookings, setDateBookings] = useState<Array<{ start_time: string; end_time: string; organization_name: string | null }>>([]);
  const [userSignature, setUserSignature] = useState<string>('');

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      start_time: '',
      end_time: '',
      organization_name: '',
      contact_person: '',
      contact_phone: '',
      purpose: '',
    },
  });

  const startTime = form.watch('start_time');
  const endTime = form.watch('end_time');

  useEffect(() => {
    if (id) {
      loadVenueData();
      loadBookingCalendar();
      loadOrganizations();
    }
  }, [id]);

  const loadOrganizations = async () => {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setOrganizations(data || []);
    } catch (error) {
      console.error('加载单位列表失败:', error);
    }
  };

  const loadVenueData = async () => {
    if (!id) return;
    
    try {
      setLoading(true);
      const venueData = await getVenue(id);
      
      if (!venueData) {
        toast.error('场地不存在');
        navigate('/venues');
        return;
      }
      
      setVenue(venueData);
    } catch (error) {
      toast.error('加载场地信息失败');
    } finally {
      setLoading(false);
    }
  };

  const loadBookingCalendar = async () => {
    if (!id) return;
    
    try {
      const today = new Date();
      const start = format(startOfMonth(today), 'yyyy-MM-dd');
      const end = format(endOfMonth(addMonths(today, 2)), 'yyyy-MM-dd');
      
      const calendar = await getVenueBookingCalendar(id, start, end);
      setBookingCalendar(calendar);
    } catch (error) {
      console.error('加载预定日历失败:', error);
    }
  };

  const handleDateSelect = async (date: Date | undefined) => {
    if (!date) return;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (date < today) {
      toast.error('不能选择过去的日期');
      return;
    }
    
    setSelectedDate(date);
    
    // 重新加载预约日历数据，确保显示最新的预约情况
    if (!id) return;
    
    try {
      const dateStr = format(date, 'yyyy-MM-dd');
      console.log('=== 选择日期 ===');
      console.log('场地ID:', id);
      console.log('选择日期:', dateStr);
      
      const today = new Date();
      const start = format(startOfMonth(today), 'yyyy-MM-dd');
      const end = format(endOfMonth(addMonths(today, 2)), 'yyyy-MM-dd');
      
      const calendar = await getVenueBookingCalendar(id, start, end);
      setBookingCalendar(calendar);
      
      // 使用最新数据获取选中日期的预定情况
      const dateBookingsFromCalendar = calendar.filter(
        b => b.booking_date === dateStr
      );
      setSelectedDateBookings(dateBookingsFromCalendar);
      console.log('日历中的预约:', dateBookingsFromCalendar);
      
      // 加载该日期的预约时间段（用于冲突提示）
      const bookings = await getDateBookings(id, dateStr);
      setDateBookings(bookings);
      console.log('有效预约（用于冲突检测）:', bookings);
    } catch (error) {
      console.error('加载预定日历失败:', error);
      // 即使加载失败也打开对话框
      setSelectedDateBookings([]);
      setDateBookings([]);
    }
    
    // 重置签名
    setUserSignature('');
    setDialogOpen(true);
  };

  // 检查日期是否有预定
  const getDateBookingStatus = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    
    // 只考虑已通过审批的预约（approved）
    // 待审核的预约（pending）不显示在日历上，避免误导其他用户
    const approvedBookings = bookingCalendar.filter(
      b => b.booking_date === dateStr && b.status === 'approved'
    );
    
    if (approvedBookings.length === 0) return null;
    
    // 计算所有预约的总时长（考虑重叠）
    // 将所有时间段合并，计算实际占用的总时长
    const timeRanges = approvedBookings.map(b => ({
      start: b.start_time,
      end: b.end_time
    })).sort((a, b) => a.start.localeCompare(b.start));
    
    // 合并重叠的时间段
    const mergedRanges: Array<{ start: string; end: string }> = [];
    for (const range of timeRanges) {
      if (mergedRanges.length === 0) {
        mergedRanges.push(range);
      } else {
        const last = mergedRanges[mergedRanges.length - 1];
        if (range.start <= last.end) {
          // 有重叠，合并
          last.end = range.end > last.end ? range.end : last.end;
        } else {
          // 无重叠，添加新的时间段
          mergedRanges.push(range);
        }
      }
    }
    
    // 计算总占用时长（小时）
    let totalHours = 0;
    for (const range of mergedRanges) {
      const startHour = parseInt(range.start.substring(0, 2));
      const startMinute = parseInt(range.start.substring(3, 5));
      const endHour = parseInt(range.end.substring(0, 2));
      const endMinute = parseInt(range.end.substring(3, 5));
      
      const hours = (endHour * 60 + endMinute - startHour * 60 - startMinute) / 60;
      totalHours += hours;
    }
    
    // 如果总占用时长 >= 8小时，视为全天已预约
    if (totalHours >= 8) {
      return 'full';
    }
    
    // 否则视为部分时段已预约
    return 'partial';
  };

  const handleSubmit = async (data: BookingFormData) => {
    if (!venue || !selectedDate || !profile) return;
    
    // 验证用户签名
    if (!userSignature) {
      toast.error('请先完成签名后再提交预约');
      return;
    }
    
    try {
      setSubmitting(true);
      
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      // 提交前重新获取最新的预约数据，确保冲突检测准确
      console.log('=== 预约提交检测 ===');
      console.log('场地ID:', venue.id);
      console.log('预约日期:', dateStr);
      console.log('预约时间:', data.start_time, '-', data.end_time);
      
      const latestBookings = await getDateBookings(venue.id, dateStr);
      console.log('该日期现有预约:', latestBookings);
      
      // 检查场地是否可用（使用时间段检查）
      const isAvailable = await checkVenueAvailability(
        venue.id, 
        dateStr, 
        data.start_time + ':00',
        data.end_time + ':00'
      );
      
      console.log('可用性检测结果:', isAvailable);
      
      if (!isAvailable) {
        // 获取冲突的预约信息
        const conflictBookings = latestBookings.filter(booking => {
          const newStart = data.start_time + ':00';
          const newEnd = data.end_time + ':00';
          const hasConflict = newEnd > booking.start_time && booking.end_time > newStart;
          console.log(`检测冲突: ${newStart}-${newEnd} vs ${booking.start_time}-${booking.end_time} = ${hasConflict}`);
          return hasConflict;
        });
        
        console.log('冲突的预约:', conflictBookings);
        
        if (conflictBookings.length > 0) {
          const conflictInfo = conflictBookings.map(b => {
            const start = b.start_time.substring(0, 5);
            const end = b.end_time.substring(0, 5);
            const org = b.organization_name || '其他单位';
            return `${org}（${start}-${end}）`;
          }).join('、');
          
          toast.error(`该时段与以下预约冲突：${conflictInfo}，请选择其他时间`, {
            duration: 5000,
          });
        } else {
          toast.error('该时段已被预定，请选择其他时间');
        }
        setSubmitting(false);
        return;
      }
      
      // 根据时间跨度计算duration
      const duration = calculateDuration(data.start_time, data.end_time);
      
      // 使用场地自己的价格
      const price = duration === 'half_day' 
        ? venue.half_day_price 
        : venue.full_day_price;
      
      // 创建预定（包含用户签名）
      await createBooking({
        venue_id: venue.id,
        user_id: profile.id,
        booking_date: dateStr,
        start_time: data.start_time + ':00',
        end_time: data.end_time + ':00',
        duration: duration,
        status: 'pending',
        original_price: price,
        final_price: price,
        organization_name: data.organization_name || null,
        contact_person: data.contact_person,
        contact_phone: data.contact_phone,
        purpose: data.purpose || null,
        admin_notes: null,
        user_signature: userSignature,
        user_signature_date: new Date().toISOString(),
        admin_signature: null,
        admin_signature_date: null,
      });
      
      toast.success('预定申请已提交，等待管理员审核');
      setDialogOpen(false);
      navigate('/my-bookings');
    } catch (error) {
      console.error('提交预定失败:', error);
      const errorMessage = error instanceof Error ? error.message : '提交预定失败';
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!venue) {
    return null;
  }

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={() => navigate('/venues')}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        返回场地列表
      </Button>

      <div className="grid gap-6 xl:grid-cols-2 grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-6 w-6" />
              {venue.name}
            </CardTitle>
            <CardDescription>
              <Badge variant="secondary">{venue.type}</Badge>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center text-sm">
              <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">位置：</span>
              <span className="ml-2">{venue.location}</span>
            </div>
            
            <div className="flex items-center text-sm">
              <Users className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="text-muted-foreground">容量：</span>
              <span className="ml-2">{venue.capacity}人</span>
            </div>
            
            {venue.description && (
              <div className="pt-2">
                <p className="text-sm text-muted-foreground">{venue.description}</p>
              </div>
            )}
            
            <div className="pt-4 border-t space-y-2">
              <h3 className="font-semibold">场地费用</h3>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">半天：</span>
                <span className="font-medium">¥{venue.half_day_price}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">全天：</span>
                <span className="font-medium">¥{venue.full_day_price}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              选择预定日期
            </CardTitle>
            <CardDescription>点击日期进行预定</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                disabled={(date) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  return date < today;
                }}
                locale={zhCN}
                className="rounded-md border"
                modifiers={{
                  booked: (date) => {
                    const status = getDateBookingStatus(date);
                    return status === 'full';
                  },
                  partial: (date) => {
                    const status = getDateBookingStatus(date);
                    return status === 'partial';
                  },
                }}
                modifiersClassNames={{
                  booked: 'bg-red-500 text-white font-bold hover:bg-red-600 dark:bg-red-600 dark:text-white',
                  partial: 'bg-orange-400 text-white font-semibold hover:bg-orange-500 dark:bg-orange-500 dark:text-white',
                }}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-3 text-sm bg-muted/50 p-4 rounded-lg">
              <div className="font-semibold text-base flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                预约状态说明
              </div>
              <div className="space-y-2">
                <div className="flex items-start gap-3">
                  <div className="min-w-[2rem] px-2 py-1 rounded-md bg-red-500 flex items-center justify-center text-white font-bold text-xs shrink-0">
                    {(() => {
                      // 查找近15天内所有全天已预约的日期
                      const today = new Date();
                      const dates: number[] = [];
                      for (let i = 0; i < 15; i++) {
                        const checkDate = new Date(today);
                        checkDate.setDate(today.getDate() + i);
                        const status = getDateBookingStatus(checkDate);
                        if (status === 'full') {
                          dates.push(checkDate.getDate());
                        }
                      }
                      return dates.length > 0 ? dates.join(',') : '—';
                    })()}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">全天已预约</div>
                    <div className="text-xs text-muted-foreground">该日期已无可用时段（累计占用≥8小时）</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="min-w-[2rem] px-2 py-1 rounded-md bg-orange-400 flex items-center justify-center text-white font-semibold text-xs shrink-0">
                    {(() => {
                      // 查找近15天内所有部分时段已预约的日期
                      const today = new Date();
                      const dates: number[] = [];
                      for (let i = 0; i < 15; i++) {
                        const checkDate = new Date(today);
                        checkDate.setDate(today.getDate() + i);
                        const status = getDateBookingStatus(checkDate);
                        if (status === 'partial') {
                          dates.push(checkDate.getDate());
                        }
                      }
                      return dates.length > 0 ? dates.join(',') : '—';
                    })()}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">部分时段已预约</div>
                    <div className="text-xs text-muted-foreground">仍有部分时段可预约（累计占用&lt;8小时）</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="min-w-[2rem] px-2 py-1 rounded-md border-2 border-border flex items-center justify-center font-normal text-xs shrink-0">
                    {(() => {
                      // 查找近15天内所有完全可预约的日期
                      const today = new Date();
                      const dates: number[] = [];
                      for (let i = 0; i < 15; i++) {
                        const checkDate = new Date(today);
                        checkDate.setDate(today.getDate() + i);
                        const status = getDateBookingStatus(checkDate);
                        if (status === null) {
                          dates.push(checkDate.getDate());
                        }
                      }
                      return dates.length > 0 ? dates.join(',') : '—';
                    })()}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">完全可预约</div>
                    <div className="text-xs text-muted-foreground">该日期暂无预约</div>
                  </div>
                </div>
              </div>
              
              {/* 显示日历中各日期的具体预约时间段 */}
              {bookingCalendar.length > 0 && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <div className="font-medium text-sm">近期预约时间段</div>
                    <div className="space-y-1.5 max-h-40 overflow-y-auto">
                      {(() => {
                        // 按日期分组预约
                        const bookingsByDate = bookingCalendar.reduce((acc, booking) => {
                          if (!acc[booking.booking_date]) {
                            acc[booking.booking_date] = [];
                          }
                          acc[booking.booking_date].push(booking);
                          return acc;
                        }, {} as Record<string, typeof bookingCalendar>);
                        
                        // 只显示已通过审批的预约（approved）
                        const validBookingsByDate = Object.entries(bookingsByDate)
                          .map(([date, bookings]) => ({
                            date,
                            bookings: bookings.filter(b => b.status === 'approved')
                          }))
                          .filter(({ bookings }) => bookings.length > 0)
                          .sort((a, b) => a.date.localeCompare(b.date))
                          .slice(0, 10); // 只显示前10天
                        
                        if (validBookingsByDate.length === 0) {
                          return (
                            <div className="text-xs text-muted-foreground py-2">
                              近期暂无预约
                            </div>
                          );
                        }
                        
                        return validBookingsByDate.map(({ date, bookings }) => (
                          <div key={date} className="text-xs p-2 bg-background rounded border">
                            <div className="font-medium text-foreground mb-1">
                              {format(new Date(date + 'T00:00:00'), 'MM月dd日 (EEEE)', { locale: zhCN })}
                            </div>
                            <div className="space-y-0.5">
                              {bookings.map((booking, idx) => (
                                <div key={idx} className="text-muted-foreground flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>
                                    {booking.start_time.substring(0, 5)} - {booking.end_time.substring(0, 5)}
                                  </span>
                                  {booking.organization_name && (
                                    <>
                                      <span className="text-muted-foreground/50">·</span>
                                      <span>{booking.organization_name}</span>
                                    </>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        ));
                      })()}
                    </div>
                  </div>
                </>
              )}
              
              <Separator />
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                💡 <span>点击日期查看详细预约情况并提交预约申请</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 预定对话框 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto max-w-[95vw] xl:max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-xl">预定场地 - {venue.name}</DialogTitle>
            <DialogDescription className="text-base">
              {selectedDate && format(selectedDate, 'yyyy年MM月dd日 EEEE', { locale: zhCN })}
            </DialogDescription>
          </DialogHeader>
          
          {/* 24小时时间轴可视化 */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-base flex items-center gap-2">
                <Clock className="h-5 w-5" />
                当日预约时间轴
              </h3>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-destructive/20 border border-destructive/40 rounded"></div>
                  <span>已预约</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-primary/20 border border-primary/40 rounded"></div>
                  <span>您的选择</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-muted border rounded"></div>
                  <span>可用</span>
                </div>
              </div>
            </div>

            {/* 时间轴 */}
            <div className="relative bg-muted/30 rounded-lg p-4 border">
              {/* 时间刻度 */}
              <div className="flex justify-between text-xs text-muted-foreground mb-2">
                <span>00:00</span>
                <span>06:00</span>
                <span>12:00</span>
                <span>18:00</span>
                <span>24:00</span>
              </div>
              
              {/* 时间轴主体 */}
              <div className="relative h-12 bg-background rounded border">
                {/* 已预约时间段 */}
                {dateBookings.map((booking, index) => {
                  const startHour = parseInt(booking.start_time.split(':')[0]);
                  const startMinute = parseInt(booking.start_time.split(':')[1]);
                  const endHour = parseInt(booking.end_time.split(':')[0]);
                  const endMinute = parseInt(booking.end_time.split(':')[1]);
                  
                  const startPercent = ((startHour * 60 + startMinute) / 1440) * 100;
                  const endPercent = ((endHour * 60 + endMinute) / 1440) * 100;
                  const widthPercent = endPercent - startPercent;
                  
                  const startTimeStr = booking.start_time.substring(0, 5);
                  const endTimeStr = booking.end_time.substring(0, 5);
                  
                  return (
                    <div
                      key={index}
                      className="absolute top-0 h-full bg-destructive/20 border-l-2 border-r-2 border-destructive/60 hover:bg-destructive/30 transition-colors group"
                      style={{
                        left: `${startPercent}%`,
                        width: `${widthPercent}%`,
                      }}
                      title={`${booking.organization_name || '未知单位'}: ${startTimeStr} - ${endTimeStr}`}
                    >
                      <div className="absolute inset-0 flex flex-col items-center justify-center px-1">
                        <span className="text-xs font-bold text-destructive leading-tight">
                          {startTimeStr}
                        </span>
                        <span className="text-xs font-bold text-destructive leading-tight">
                          {endTimeStr}
                        </span>
                        <span className="text-[10px] text-destructive/80 opacity-0 group-hover:opacity-100 transition-opacity truncate w-full text-center">
                          {booking.organization_name || '已预约'}
                        </span>
                      </div>
                    </div>
                  );
                })}
                
                {/* 用户选择的时间段 */}
                {startTime && endTime && (() => {
                  const [startHour, startMinute] = startTime.split(':').map(Number);
                  const [endHour, endMinute] = endTime.split(':').map(Number);
                  
                  const startPercent = ((startHour * 60 + startMinute) / 1440) * 100;
                  const endPercent = ((endHour * 60 + endMinute) / 1440) * 100;
                  const widthPercent = endPercent - startPercent;
                  
                  // 检查是否冲突
                  const newStart = startTime + ':00';
                  const newEnd = endTime + ':00';
                  const hasConflict = dateBookings.some(booking => 
                    newEnd > booking.start_time && booking.end_time > newStart
                  );
                  
                  return (
                    <div
                      className={`absolute top-0 h-full border-l-2 border-r-2 transition-colors ${
                        hasConflict 
                          ? 'bg-destructive/40 border-destructive animate-pulse' 
                          : 'bg-primary/30 border-primary'
                      }`}
                      style={{
                        left: `${startPercent}%`,
                        width: `${widthPercent}%`,
                      }}
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className={`text-xs font-bold ${hasConflict ? 'text-destructive' : 'text-primary'}`}>
                          {startTime} - {endTime}
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>
              
              {/* 时间刻度线 */}
              <div className="relative h-2 mt-1">
                {[0, 6, 12, 18, 24].map((hour) => (
                  <div
                    key={hour}
                    className="absolute top-0 w-px h-2 bg-muted-foreground/30"
                    style={{ left: `${(hour / 24) * 100}%` }}
                  />
                ))}
              </div>
            </div>

            {/* 已预约列表（简化版） */}
            {dateBookings.length > 0 && (
              <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                <div className="text-sm font-medium flex items-center gap-2">
                  <Building className="h-4 w-4" />
                  已预约时段详情（{dateBookings.length}个）
                </div>
                <div className="grid gap-2">
                  {dateBookings.map((booking, index) => (
                    <div key={index} className="flex items-center justify-between text-sm bg-background rounded px-3 py-2 border">
                      <span className="font-medium">{booking.organization_name || '未知单位'}</span>
                      <span className="text-muted-foreground">
                        {booking.start_time.substring(0, 5)} - {booking.end_time.substring(0, 5)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* 实时冲突警告 */}
            {startTime && endTime && (() => {
              const newStart = startTime + ':00';
              const newEnd = endTime + ':00';
              const conflicts = dateBookings.filter(booking => 
                newEnd > booking.start_time && booking.end_time > newStart
              );
              
              if (conflicts.length > 0) {
                return (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <div className="font-semibold mb-1">时间冲突！</div>
                      <div className="text-sm">
                        您选择的时间段与 {conflicts.map(b => b.organization_name || '其他单位').join('、')} 的预约冲突，请重新选择时间。
                      </div>
                    </AlertDescription>
                  </Alert>
                );
              }
              
              return (
                <Alert className="bg-primary/10 border-primary/30">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <AlertDescription className="text-primary">
                    <div className="font-semibold">时间段可用！</div>
                    <div className="text-sm">您选择的时间段没有冲突，可以提交预约。</div>
                  </AlertDescription>
                </Alert>
              );
            })()}
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              {/* 时间选择 - 手动输入，精确到分钟 */}
              <div className="grid gap-4 xl:grid-cols-2 grid-cols-1">
                <FormField
                  control={form.control}
                  name="start_time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>开始时间</FormLabel>
                      <FormControl>
                        <Input 
                          type="time" 
                          {...field} 
                          placeholder="HH:MM"
                          className="text-base"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="end_time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>结束时间</FormLabel>
                      <FormControl>
                        <Input 
                          type="time" 
                          {...field} 
                          placeholder="HH:MM"
                          className="text-base"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* 显示预计费用 */}
              {startTime && endTime && startTime < endTime && (
                <div className="bg-muted p-3 rounded-lg text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">预计时长：</span>
                    <span className="font-medium">
                      {(() => {
                        const duration = calculateDuration(startTime, endTime);
                        return duration === 'half_day' ? '半天（≤4小时）' : '全天（>4小时）';
                      })()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-muted-foreground">预计费用：</span>
                    <span className="font-bold text-primary">
                      ¥{(() => {
                        const duration = calculateDuration(startTime, endTime);
                        return duration === 'half_day' ? venue.half_day_price : venue.full_day_price;
                      })()}
                    </span>
                  </div>
                </div>
              )}

              <FormField
                control={form.control}
                name="organization_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>预约单位 <span className="text-destructive">*</span></FormLabel>
                    {!customOrganization ? (
                      <div className="space-y-2">
                        <Select
                          value={field.value}
                          onValueChange={(value) => {
                            if (value === '__custom__') {
                              setCustomOrganization(true);
                              field.onChange('');
                            } else {
                              field.onChange(value);
                            }
                          }}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="请选择预约单位" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {organizations.map((org) => (
                              <SelectItem key={org.id} value={org.name}>
                                {org.name}
                              </SelectItem>
                            ))}
                            <SelectItem value="__custom__">
                              <span className="text-primary">+ 自定义单位名称</span>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <FormControl>
                          <Input placeholder="请输入单位名称" {...field} />
                        </FormControl>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setCustomOrganization(false);
                            field.onChange('');
                          }}
                        >
                          返回选择列表
                        </Button>
                      </div>
                    )}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contact_person"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>联系人</FormLabel>
                    <FormControl>
                      <Input placeholder="请输入联系人姓名" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contact_phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>联系电话</FormLabel>
                    <FormControl>
                      <Input placeholder="请输入联系电话" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="purpose"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>使用说明 <span className="text-destructive">*</span></FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="请详细说明场地使用目的、活动内容等信息" 
                        className="min-h-[100px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* 使用人签名 */}
              <div className="space-y-2">
                <Alert className="bg-yellow-50 border-yellow-200 py-2">
                  <FileSignature className="h-4 w-4" />
                  <AlertDescription className="text-xs xl:text-sm">
                    <strong>提示：</strong>提交预约前必须完成签名
                  </AlertDescription>
                </Alert>
                
                <Label className="text-sm xl:text-base font-semibold">使用人签名 *</Label>
                {userSignature ? (
                  <div className="space-y-2">
                    <div className="p-2 xl:p-4 border rounded-lg bg-muted">
                      <img 
                        src={userSignature} 
                        alt="使用人签名" 
                        className="max-h-20 xl:max-h-32 mx-auto border rounded bg-white"
                      />
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setUserSignature('')}
                      className="w-full"
                    >
                      重新签名
                    </Button>
                  </div>
                ) : (
                  <SignaturePad
                    onSave={(signature) => {
                      setUserSignature(signature);
                      toast.success('签名已保存，请继续填写表单并提交');
                    }}
                    width={280}
                    height={120}
                  />
                )}
              </div>

              <DialogFooter className="gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  取消
                </Button>
                <Button type="submit" disabled={submitting || !userSignature}>
                  {submitting ? '提交中...' : '提交预约'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
