import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, Calendar, Users, Clock, TrendingUp, BarChart3 } from 'lucide-react';
import { getStatistics, getPendingBookingsCount, getVenueUsageStats, getBookingTrend, getBookingStatusDistribution } from '@/db/api';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function Dashboard() {
  const { profile } = useAuth();
  const [stats, setStats] = useState({
    totalVenues: 0,
    totalBookings: 0,
    totalUsers: 0,
  });
  const [pendingCount, setPendingCount] = useState(0);
  const [venueUsage, setVenueUsage] = useState<Array<{ name: string; count: number }>>([]);
  const [bookingTrend, setBookingTrend] = useState<Array<{ date: string; total: number; approved: number; pending: number }>>([]);
  const [statusDistribution, setStatusDistribution] = useState<Array<{ name: string; value: number }>>([]);
  const [loading, setLoading] = useState(true);
  const isAdmin = profile?.role === 'admin';

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [statsData, pending, usage, trend, distribution] = await Promise.all([
        getStatistics(),
        isAdmin ? getPendingBookingsCount() : Promise.resolve(0),
        isAdmin ? getVenueUsageStats() : Promise.resolve([]),
        isAdmin ? getBookingTrend() : Promise.resolve([]),
        isAdmin ? getBookingStatusDistribution() : Promise.resolve([]),
      ]);
      setStats(statsData);
      setPendingCount(pending);
      setVenueUsage(usage);
      setBookingTrend(trend);
      setStatusDistribution(distribution);
    } catch (error) {
      console.error('加载数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">欢迎回来，{profile?.username}</h1>
        <p className="text-muted-foreground mt-2">
          {isAdmin ? '管理员控制面板' : '场地预定系统'}
        </p>
      </div>

      <div className="grid gap-4 xl:grid-cols-4 grid-cols-1 @container">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">场地总数</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalVenues}</div>
            <p className="text-xs text-muted-foreground mt-1">可预定场地数量</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">预定总数</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalBookings}</div>
            <p className="text-xs text-muted-foreground mt-1">累计预定次数</p>
          </CardContent>
        </Card>

        {isAdmin && (
          <>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">用户总数</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalUsers}</div>
                <p className="text-xs text-muted-foreground mt-1">注册用户数量</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">待审核</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{pendingCount}</div>
                <p className="text-xs text-muted-foreground mt-1">待审核预定</p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>快速开始</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {isAdmin ? (
            <>
              <p className="text-sm text-muted-foreground">• 在场地管理中添加或编辑场地信息</p>
              <p className="text-sm text-muted-foreground">• 在预定管理中审核用户的预定申请</p>
              <p className="text-sm text-muted-foreground">• 在费用管理中设置场地定价</p>
              <p className="text-sm text-muted-foreground">• 在用户管理中管理用户权限</p>
            </>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">• 在场地列表中浏览可用场地</p>
              <p className="text-sm text-muted-foreground">• 选择场地和日期进行预定</p>
              <p className="text-sm text-muted-foreground">• 在我的预定中查看预定状态</p>
            </>
          )}
        </CardContent>
      </Card>

      {/* 管理员可视化数据 */}
      {isAdmin && !loading && (
        <>
          {/* 预定趋势图 */}
          {bookingTrend.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  预定趋势（最近7天）
                </CardTitle>
                <CardDescription>查看最近一周的预定情况变化</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={bookingTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={(value) => format(new Date(value), 'MM-dd', { locale: zhCN })}
                    />
                    <YAxis />
                    <Tooltip 
                      labelFormatter={(value) => format(new Date(value as string), 'yyyy年MM月dd日', { locale: zhCN })}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="total" stroke="#2563eb" name="总预定" strokeWidth={2} />
                    <Line type="monotone" dataKey="approved" stroke="#10b981" name="已通过" strokeWidth={2} />
                    <Line type="monotone" dataKey="pending" stroke="#f59e0b" name="待审核" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-6 xl:grid-cols-2 grid-cols-1">
            {/* 场地使用率 */}
            {venueUsage.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    场地使用率
                  </CardTitle>
                  <CardDescription>各场地的预定次数统计</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={venueUsage.slice(0, 5)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" fill="#2563eb" name="预定次数" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* 预定状态分布 */}
            {statusDistribution.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>预定状态分布</CardTitle>
                  <CardDescription>各状态预定数量占比</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={statusDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {statusDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </div>
        </>
      )}
    </div>
  );
}
