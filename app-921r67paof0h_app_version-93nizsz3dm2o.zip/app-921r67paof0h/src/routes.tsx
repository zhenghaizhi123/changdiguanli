import { Navigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import LoginPage from '@/pages/LoginPage';
import Dashboard from '@/pages/Dashboard';
import VenuesPage from '@/pages/VenuesPage';
import VenueDetailPage from '@/pages/VenueDetailPage';
import VenueSchedulePage from '@/pages/VenueSchedulePage';
import MyBookingsPage from '@/pages/MyBookingsPage';
import BookingManagementPage from '@/pages/BookingManagementPage';
import BookingOverviewPage from '@/pages/BookingOverviewPage';
import StatisticsPage from '@/pages/StatisticsPage';
import PricingManagementPage from '@/pages/PricingManagementPage';
import OrganizationManagementPage from '@/pages/OrganizationManagementPage';
import AdminPage from '@/pages/AdminPage';
import NotFound from '@/pages/NotFound';

export interface RouteConfig {
  path: string;
  element: React.ReactNode;
  children?: RouteConfig[];
}

const routes: RouteConfig[] = [
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="/dashboard" replace />,
      },
      {
        path: 'dashboard',
        element: <Dashboard />,
      },
      {
        path: 'venues',
        element: <VenuesPage />,
      },
      {
        path: 'venues/:id',
        element: <VenueDetailPage />,
      },
      {
        path: 'venue-schedule',
        element: <VenueSchedulePage />,
      },
      {
        path: 'my-bookings',
        element: <MyBookingsPage />,
      },
      {
        path: 'bookings',
        element: <BookingManagementPage />,
      },
      {
        path: 'booking-overview',
        element: <BookingOverviewPage />,
      },
      {
        path: 'statistics',
        element: <StatisticsPage />,
      },
      {
        path: 'pricing',
        element: <PricingManagementPage />,
      },
      {
        path: 'organizations',
        element: <OrganizationManagementPage />,
      },
      {
        path: 'admin',
        element: <AdminPage />,
      },
    ],
  },
  {
    path: '/404',
    element: <NotFound />,
  },
  {
    path: '*',
    element: <Navigate to="/404" replace />,
  },
];

export default routes;
