import { supabase } from './supabase';
import type { Venue, VenuePricing, Booking, BookingDetail, Profile, BookingStatus, VenueType } from '@/types';

// ==================== 场地管理 ====================

// 获取所有场地
export async function getVenues(activeOnly = false): Promise<Venue[]> {
  let query = supabase.from('venues').select('*').order('created_at', { ascending: false });
  
  if (activeOnly) {
    query = query.eq('is_active', true);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('获取场地列表失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 获取单个场地
export async function getVenue(id: string): Promise<Venue | null> {
  const { data, error } = await supabase
    .from('venues')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  
  if (error) {
    console.error('获取场地详情失败:', error);
    throw error;
  }
  
  return data;
}

// 创建场地
export async function createVenue(venue: Omit<Venue, 'id' | 'created_at' | 'updated_at'>): Promise<Venue> {
  const { data, error } = await supabase
    .from('venues')
    .insert(venue)
    .select()
    .single();
  
  if (error) {
    console.error('创建场地失败:', error);
    throw error;
  }
  
  return data;
}

// 更新场地
export async function updateVenue(id: string, updates: Partial<Venue>): Promise<Venue> {
  const { data, error } = await supabase
    .from('venues')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('更新场地失败:', error);
    throw error;
  }
  
  return data;
}

// 删除场地
export async function deleteVenue(id: string): Promise<void> {
  const { error } = await supabase
    .from('venues')
    .delete()
    .eq('id', id);
  
  if (error) {
    console.error('删除场地失败:', error);
    throw error;
  }
}

// ==================== 场地定价管理 ====================

// 获取所有定价
export async function getVenuePricing(): Promise<VenuePricing[]> {
  const { data, error } = await supabase
    .from('venue_pricing')
    .select('*')
    .order('venue_type');
  
  if (error) {
    console.error('获取定价失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 获取指定类型的定价
export async function getVenuePricingByType(venueType: VenueType): Promise<VenuePricing | null> {
  const { data, error } = await supabase
    .from('venue_pricing')
    .select('*')
    .eq('venue_type', venueType)
    .maybeSingle();
  
  if (error) {
    console.error('获取定价失败:', error);
    throw error;
  }
  
  return data;
}

// 更新定价
export async function updateVenuePricing(
  venueType: VenueType,
  updates: { half_day_price?: number; full_day_price?: number }
): Promise<VenuePricing> {
  const { data, error } = await supabase
    .from('venue_pricing')
    .update(updates)
    .eq('venue_type', venueType)
    .select()
    .single();
  
  if (error) {
    console.error('更新定价失败:', error);
    throw error;
  }
  
  return data;
}

// ==================== 预定管理 ====================

// 获取所有预定（管理员）
export async function getAllBookings(): Promise<BookingDetail[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select(`
      *,
      venue:venues!bookings_venue_id_fkey(*),
      user:profiles!bookings_user_id_fkey(*)
    `)
    .order('booking_date', { ascending: false })
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('获取预定列表失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 获取用户的预定
export async function getUserBookings(userId: string): Promise<BookingDetail[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select(`
      *,
      venue:venues!bookings_venue_id_fkey(*)
    `)
    .eq('user_id', userId)
    .order('booking_date', { ascending: false })
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('获取用户预定失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 获取场地的预定
export async function getVenueBookings(venueId: string): Promise<Booking[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('*')
    .eq('venue_id', venueId)
    .order('booking_date', { ascending: false });
  
  if (error) {
    console.error('获取场地预定失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 获取场地的预定日历（包含用户信息，用于展示共享情况）
export async function getVenueBookingCalendar(
  venueId: string,
  startDate?: string,
  endDate?: string
): Promise<BookingDetail[]> {
  let query = supabase
    .from('bookings')
    .select(`
      *,
      user:profiles!bookings_user_id_fkey(id, username)
    `)
    .eq('venue_id', venueId)
    .in('status', ['pending', 'approved', 'completed'])
    .order('booking_date', { ascending: true });
  
  if (startDate) {
    query = query.gte('booking_date', startDate);
  }
  
  if (endDate) {
    query = query.lte('booking_date', endDate);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('获取场地预定日历失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 检查场地是否可预定（支持时间段检查）
// 只检查已通过审批的预约（approved），待审核的预约（pending）不影响可用性判断
export async function checkVenueAvailability(
  venueId: string,
  bookingDate: string,
  startTime: string,
  endTime: string
): Promise<boolean> {
  console.log('=== checkVenueAvailability ===');
  console.log('参数:', { venueId, bookingDate, startTime, endTime });
  
  // 查询该日期该场地的所有已通过审批的预定
  const { data, error } = await supabase
    .from('bookings')
    .select('start_time, end_time, organization_name')
    .eq('venue_id', venueId)
    .eq('booking_date', bookingDate)
    .eq('status', 'approved'); // 只检查已通过审批的预约
  
  if (error) {
    console.error('检查场地可用性失败:', error);
    throw error;
  }
  
  console.log('查询到的预约:', data);
  
  // 如果没有预定，则可用
  if (!data || data.length === 0) {
    console.log('没有预约，可用');
    return true;
  }
  
  // 检查时间段是否冲突
  // 两个时间段冲突的条件：新预定结束时间 > 已有预定开始时间 AND 已有预定结束时间 > 新预定开始时间
  for (const booking of data) {
    const hasConflict = endTime > booking.start_time && booking.end_time > startTime;
    console.log(`检测: ${startTime}-${endTime} vs ${booking.start_time}-${booking.end_time} = ${hasConflict ? '冲突' : '不冲突'}`);
    
    if (hasConflict) {
      console.log('发现冲突，不可用');
      return false;
    }
  }
  
  console.log('无冲突，可用');
  return true;
}

// 获取指定日期的预约时间段（用于显示冲突提示）
// 只返回已通过审批的预约（approved），待审核的预约（pending）不显示
export async function getDateBookings(
  venueId: string,
  bookingDate: string
): Promise<Array<{ start_time: string; end_time: string; organization_name: string | null }>> {
  const { data, error } = await supabase
    .from('bookings')
    .select('start_time, end_time, organization_name')
    .eq('venue_id', venueId)
    .eq('booking_date', bookingDate)
    .eq('status', 'approved') // 只显示已通过审批的预约
    .order('start_time');
  
  if (error) {
    console.error('获取日期预约失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 创建预定
export async function createBooking(booking: Omit<Booking, 'id' | 'created_at' | 'updated_at'>): Promise<Booking> {
  const { data, error } = await supabase
    .from('bookings')
    .insert(booking)
    .select()
    .single();
  
  if (error) {
    console.error('创建预定失败:', error);
    throw error;
  }
  
  return data;
}

// 更新预定
export async function updateBooking(id: string, updates: Partial<Booking>): Promise<Booking> {
  const { data, error } = await supabase
    .from('bookings')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('更新预定失败:', error);
    throw error;
  }
  
  return data;
}

// 取消预定
export async function cancelBooking(id: string): Promise<Booking> {
  return updateBooking(id, { status: 'cancelled' });
}

// 删除预定（管理员）
export async function deleteBooking(id: string): Promise<void> {
  const { error } = await supabase
    .from('bookings')
    .delete()
    .eq('id', id);
  
  if (error) {
    console.error('删除预定失败:', error);
    throw error;
  }
}

// 审核预定
export async function reviewBooking(
  id: string,
  status: BookingStatus,
  adminNotes?: string
): Promise<Booking> {
  return updateBooking(id, { status, admin_notes: adminNotes || null });
}

// 使用人签字
export async function userSignBooking(id: string, signature: string): Promise<Booking> {
  const { data, error } = await supabase
    .from('bookings')
    .update({
      user_signature: signature,
      user_signature_date: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('使用人签字失败:', error);
    throw error;
  }

  if (!data) {
    throw new Error('签字失败：未找到预约记录');
  }

  return data;
}

// 管理员签字
export async function adminSignBooking(id: string, signature: string): Promise<Booking> {
  const { data, error } = await supabase
    .from('bookings')
    .update({
      admin_signature: signature,
      admin_signature_date: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('管理员签字失败:', error);
    throw error;
  }

  if (!data) {
    throw new Error('签字失败：未找到预约记录');
  }

  return data;
}

// ==================== 用户管理 ====================

// 获取所有用户
export async function getAllUsers(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) {
    console.error('获取用户列表失败:', error);
    throw error;
  }
  
  return Array.isArray(data) ? data : [];
}

// 更新用户角色
export async function updateUserRole(userId: string, role: string): Promise<Profile> {
  const { data, error } = await supabase
    .from('profiles')
    .update({ role })
    .eq('id', userId)
    .select()
    .single();
  
  if (error) {
    console.error('更新用户角色失败:', error);
    throw error;
  }
  
  return data;
}

// ==================== 统计数据 ====================

// 获取统计数据
export async function getStatistics() {
  const [venuesResult, bookingsResult, usersResult] = await Promise.all([
    supabase.from('venues').select('id', { count: 'exact', head: true }),
    supabase.from('bookings').select('id', { count: 'exact', head: true }),
    supabase.from('profiles').select('id', { count: 'exact', head: true }),
  ]);
  
  return {
    totalVenues: venuesResult.count || 0,
    totalBookings: bookingsResult.count || 0,
    totalUsers: usersResult.count || 0,
  };
}

// 获取待审核预定数量
export async function getPendingBookingsCount(): Promise<number> {
  const { count, error } = await supabase
    .from('bookings')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'pending');
  
  if (error) {
    console.error('获取待审核预定数量失败:', error);
    return 0;
  }
  
  return count || 0;
}

// 获取场地使用率统计
export async function getVenueUsageStats() {
  const { data, error } = await supabase
    .from('bookings')
    .select(`
      venue_id,
      venues!inner(name, type)
    `)
    .in('status', ['approved', 'completed']);
  
  if (error) {
    console.error('获取场地使用统计失败:', error);
    return [];
  }
  
  // 统计每个场地的预定次数
  const usageMap = new Map<string, { name: string; type: string; count: number }>();
  
  for (const booking of data || []) {
    const venue = booking.venues as unknown as { name: string; type: string };
    const key = booking.venue_id;
    
    if (usageMap.has(key)) {
      usageMap.get(key)!.count++;
    } else {
      usageMap.set(key, {
        name: venue.name,
        type: venue.type,
        count: 1,
      });
    }
  }
  
  return Array.from(usageMap.values()).sort((a, b) => b.count - a.count);
}

// 获取预定趋势数据（最近7天）
export async function getBookingTrend() {
  const today = new Date();
  const sevenDaysAgo = new Date(today);
  sevenDaysAgo.setDate(today.getDate() - 6);
  
  const { data, error } = await supabase
    .from('bookings')
    .select('booking_date, status')
    .gte('booking_date', sevenDaysAgo.toISOString().split('T')[0])
    .lte('booking_date', today.toISOString().split('T')[0])
    .order('booking_date');
  
  if (error) {
    console.error('获取预定趋势失败:', error);
    return [];
  }
  
  // 按日期统计
  const trendMap = new Map<string, { date: string; total: number; approved: number; pending: number }>();
  
  // 初始化最近7天的数据
  for (let i = 0; i < 7; i++) {
    const date = new Date(sevenDaysAgo);
    date.setDate(sevenDaysAgo.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];
    trendMap.set(dateStr, {
      date: dateStr,
      total: 0,
      approved: 0,
      pending: 0,
    });
  }
  
  // 填充实际数据
  for (const booking of data || []) {
    const dateStr = booking.booking_date;
    if (trendMap.has(dateStr)) {
      const stat = trendMap.get(dateStr)!;
      stat.total++;
      if (booking.status === 'approved' || booking.status === 'completed') {
        stat.approved++;
      } else if (booking.status === 'pending') {
        stat.pending++;
      }
    }
  }
  
  return Array.from(trendMap.values());
}

// 获取预定状态分布
export async function getBookingStatusDistribution() {
  const { data, error } = await supabase
    .from('bookings')
    .select('status');
  
  if (error) {
    console.error('获取预定状态分布失败:', error);
    return [];
  }
  
  const statusMap = new Map<string, number>();
  const statusLabels: Record<string, string> = {
    pending: '待审核',
    approved: '已通过',
    rejected: '已拒绝',
    cancelled: '已取消',
    completed: '已完成',
  };
  
  for (const booking of data || []) {
    const count = statusMap.get(booking.status) || 0;
    statusMap.set(booking.status, count + 1);
  }
  
  return Array.from(statusMap.entries()).map(([status, count]) => ({
    name: statusLabels[status] || status,
    value: count,
  }));
}

// ==================== 单位统计 ====================

// 单位统计数据类型
export interface OrganizationStats {
  organization_name: string;
  booking_count: number;
  total_amount: number;
}

// 获取单位统计（支持按年度筛选）
export async function getOrganizationStats(
  organizationName?: string,
  year?: number,
  startDate?: string,
  endDate?: string
): Promise<OrganizationStats[]> {
  let query = supabase
    .from('bookings')
    .select('organization_name, final_price, booking_date')
    .not('organization_name', 'is', null)
    .in('status', ['approved', 'completed']);
  
  // 如果指定单位，只查询该单位
  if (organizationName) {
    query = query.eq('organization_name', organizationName);
  }
  
  // 如果指定了自定义日期范围，使用自定义日期
  if (startDate && endDate) {
    query = query.gte('booking_date', startDate).lte('booking_date', endDate);
  }
  // 否则如果指定年份，筛选该年份的数据
  else if (year) {
    const yearStartDate = `${year}-01-01`;
    const yearEndDate = `${year}-12-31`;
    query = query.gte('booking_date', yearStartDate).lte('booking_date', yearEndDate);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('获取单位统计失败:', error);
    throw error;
  }
  
  // 按单位聚合统计
  const statsMap = new Map<string, OrganizationStats>();
  
  for (const booking of data || []) {
    const orgName = booking.organization_name!;
    if (!statsMap.has(orgName)) {
      statsMap.set(orgName, {
        organization_name: orgName,
        booking_count: 0,
        total_amount: 0,
      });
    }
    
    const stats = statsMap.get(orgName)!;
    stats.booking_count++;
    stats.total_amount += booking.final_price;
  }
  
  // 转换为数组并按使用次数降序排序
  return Array.from(statsMap.values()).sort((a, b) => b.booking_count - a.booking_count);
}

// 获取所有有预定记录的单位列表
export async function getOrganizationList(): Promise<string[]> {
  const { data, error } = await supabase
    .from('bookings')
    .select('organization_name')
    .not('organization_name', 'is', null);
  
  if (error) {
    console.error('获取单位列表失败:', error);
    throw error;
  }
  
  // 去重并排序
  const orgSet = new Set<string>();
  for (const booking of data || []) {
    if (booking.organization_name) {
      orgSet.add(booking.organization_name);
    }
  }
  
  return Array.from(orgSet).sort();
}

// 场地统计数据类型
export interface VenueStats {
  venue_id: string;
  venue_name: string;
  venue_type: string;
  capacity: number;
  location: string;
  booking_count: number;
  total_amount: number;
}

// 获取场地统计数据
export async function getVenueStats(
  startDate?: string,
  endDate?: string,
  organizationName?: string
): Promise<VenueStats[]> {
  try {
    // 构建查询
    let query = supabase
      .from('bookings')
      .select(`
        venue_id,
        final_price,
        organization_name,
        venues!inner(name, type, capacity, location)
      `)
      .in('status', ['approved', 'completed']);
    
    // 添加日期范围筛选
    if (startDate) {
      query = query.gte('booking_date', startDate);
    }
    if (endDate) {
      query = query.lte('booking_date', endDate);
    }
    
    // 添加单位筛选
    if (organizationName) {
      query = query.eq('organization_name', organizationName);
    }
    
    const { data, error } = await query;
    
    if (error) {
      console.error('获取场地统计失败:', error);
      throw error;
    }
    
    // 按场地ID分组统计
    const statsMap = new Map<string, VenueStats>();
    
    for (const booking of data || []) {
      const venue = booking.venues as unknown as { 
        name: string; 
        type: string; 
        capacity: number; 
        location: string;
      };
      const venueId = booking.venue_id;
      
      if (statsMap.has(venueId)) {
        const stat = statsMap.get(venueId)!;
        stat.booking_count++;
        stat.total_amount += booking.final_price;
      } else {
        statsMap.set(venueId, {
          venue_id: venueId,
          venue_name: venue.name,
          venue_type: venue.type,
          capacity: venue.capacity,
          location: venue.location,
          booking_count: 1,
          total_amount: booking.final_price,
        });
      }
    }
    
    // 获取所有场地（包括没有预约记录的）
    const { data: allVenues, error: venuesError } = await supabase
      .from('venues')
      .select('id, name, type, capacity, location');
    
    if (venuesError) {
      console.error('获取场地列表失败:', venuesError);
      throw venuesError;
    }
    
    // 补充没有预约记录的场地
    for (const venue of allVenues || []) {
      if (!statsMap.has(venue.id)) {
        statsMap.set(venue.id, {
          venue_id: venue.id,
          venue_name: venue.name,
          venue_type: venue.type,
          capacity: venue.capacity,
          location: venue.location,
          booking_count: 0,
          total_amount: 0,
        });
      }
    }
    
    // 转换为数组并按预约次数降序排序
    return Array.from(statsMap.values()).sort((a, b) => b.booking_count - a.booking_count);
  } catch (error) {
    console.error('获取场地统计失败:', error);
    throw error;
  }
}
