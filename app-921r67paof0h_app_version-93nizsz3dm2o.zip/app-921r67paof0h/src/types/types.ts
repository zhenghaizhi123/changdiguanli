// 用户角色
export type UserRole = 'user' | 'admin';

// 场地类型 - 现在支持自定义类型（任意字符串）
export type VenueType = string;

// 预定时长
export type BookingDuration = 'half_day' | 'full_day';

// 预定状态
export type BookingStatus = 'pending' | 'approved' | 'rejected' | 'completed' | 'cancelled';

// 用户资料
export interface Profile {
  id: string;
  username: string | null;
  email: string | null;
  phone: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

// 场地
export interface Venue {
  id: string;
  name: string;
  type: VenueType;
  capacity: number;
  location: string;
  description: string | null;
  is_active: boolean;
  half_day_price: number;
  full_day_price: number;
  created_at: string;
  updated_at: string;
}

// 场地定价
export interface VenuePricing {
  id: string;
  venue_type: VenueType;
  half_day_price: number;
  full_day_price: number;
  created_at: string;
  updated_at: string;
}

// 预定
export interface Booking {
  id: string;
  venue_id: string;
  user_id: string;
  booking_date: string;
  start_time: string; // 格式: HH:mm:ss
  end_time: string;   // 格式: HH:mm:ss
  duration: BookingDuration;
  status: BookingStatus;
  original_price: number;
  final_price: number;
  organization_name: string | null;
  contact_person: string | null;
  contact_phone: string | null;
  purpose: string | null;
  admin_notes: string | null;
  user_signature: string | null;
  user_signature_date: string | null;
  admin_signature: string | null;
  admin_signature_date: string | null;
  created_at: string;
  updated_at: string;
}

// 预定详情（包含关联数据）
export interface BookingDetail extends Booking {
  venue?: Venue;
  user?: Profile;
}

// 预定时长标签
export const BOOKING_DURATION_LABELS: Record<BookingDuration, string> = {
  half_day: '半天',
  full_day: '全天',
};

// 预定状态标签
export const BOOKING_STATUS_LABELS: Record<BookingStatus, string> = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已拒绝',
  completed: '已完成',
  cancelled: '已取消',
};

// 预定状态颜色
export const BOOKING_STATUS_COLORS: Record<BookingStatus, string> = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  approved: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  rejected: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
  completed: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  cancelled: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
};
