// 微信环境检测工具
export function isWechat(): boolean {
  const ua = navigator.userAgent.toLowerCase();
  return /micromessenger/.test(ua);
}

export function isWechatMiniProgram(): boolean {
  const ua = navigator.userAgent.toLowerCase();
  return /miniprogram/.test(ua);
}

// 微信小程序webview环境检测
export function checkWechatEnv(): {
  isWechat: boolean;
  isMiniProgram: boolean;
} {
  return {
    isWechat: isWechat(),
    isMiniProgram: isWechatMiniProgram(),
  };
}

// 禁用微信内置的长按菜单（如果需要）
export function disableWechatMenu(): void {
  if (isWechat()) {
    document.addEventListener('WeixinJSBridgeReady', () => {
      // 微信环境准备就绪
      console.log('微信环境已就绪');
    });
  }
}
