import { Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Building2, Calendar, ClipboardList, Home, LogOut, Menu, Settings, Users, TableProperties, BarChart3, Building } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ThemeToggle } from '@/components/theme-toggle';

const userNavItems = [
  { icon: Home, label: '工作台', path: '/dashboard' },
  { icon: Building2, label: '场地预约', path: '/venues' },
  { icon: Calendar, label: '我的预约', path: '/my-bookings' },
  { icon: BarChart3, label: '使用统计', path: '/statistics' },
];

const adminNavItems = [
  { icon: Home, label: '工作台', path: '/dashboard' },
  { icon: Building2, label: '场地管理', path: '/venues' },
  { icon: ClipboardList, label: '预约审核', path: '/bookings' },
  { icon: TableProperties, label: '预约总览', path: '/booking-overview' },
  { icon: BarChart3, label: '数据统计', path: '/statistics' },
  { icon: Settings, label: '费用设置', path: '/pricing' },
  { icon: Building, label: '单位管理', path: '/organizations' },
  { icon: Users, label: '用户管理', path: '/admin' },
];

function NavLinks({ items, onClick }: { items: typeof userNavItems; onClick?: () => void }) {
  const location = useLocation();
  
  return (
    <nav className="space-y-1">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = location.pathname === item.path;
        
        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={onClick}
            className={cn(
              'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
              isActive
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
            )}
          >
            <Icon className="h-5 w-5" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function MainLayout() {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const isAdmin = profile?.role === 'admin';
  const navItems = isAdmin ? adminNavItems : userNavItems;

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen w-full">
      {/* 桌面端侧边栏 */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:border-r lg:bg-sidebar shrink-0">
        <div className="flex h-16 items-center border-b px-6">
          <Building2 className="h-6 w-6 text-primary" />
          <span className="ml-2 text-lg font-semibold">场地管理系统</span>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <NavLinks items={navItems} />
        </div>
        
        <div className="border-t p-4 space-y-2">
          <div className="px-3 py-2 text-sm">
            <div className="font-medium">{profile?.username || '用户'}</div>
            <div className="text-xs text-muted-foreground">
              {isAdmin ? '管理员' : '普通用户'}
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={handleSignOut}
          >
            <LogOut className="mr-2 h-4 w-4" />
            退出登录
          </Button>
        </div>
      </aside>

      {/* 主内容区 */}
      <div className="flex-1 flex flex-col">
        {/* 移动端顶部栏 */}
        <header className="lg:hidden flex h-16 items-center gap-4 border-b bg-background px-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <div className="flex h-16 items-center border-b px-6">
                <Building2 className="h-6 w-6 text-primary" />
                <span className="ml-2 text-lg font-semibold">场地管理</span>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4">
                <NavLinks items={navItems} />
              </div>
              
              <div className="border-t p-4 space-y-2">
                <div className="px-3 py-2 text-sm">
                  <div className="font-medium">{profile?.username || '用户'}</div>
                  <div className="text-xs text-muted-foreground">
                    {isAdmin ? '管理员' : '普通用户'}
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={handleSignOut}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  退出登录
                </Button>
              </div>
            </SheetContent>
          </Sheet>
          
          <div className="flex-1 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              <span className="font-semibold">场地管理系统</span>
            </div>
            <ThemeToggle />
          </div>
        </header>

        {/* 桌面端顶部栏 */}
        <header className="hidden lg:flex h-16 items-center justify-end gap-4 border-b bg-background px-6">
          <ThemeToggle />
        </header>

        {/* 页面内容 */}
        <main className="flex-1 overflow-y-auto p-4 xl:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
