-- 添加预约时间字段
ALTER TABLE bookings
ADD COLUMN start_time TIME,
ADD COLUMN end_time TIME;

-- 更新现有数据：根据 duration 设置默认时间
UPDATE bookings
SET 
  start_time = CASE 
    WHEN duration = 'half_day' THEN '09:00:00'::TIME
    WHEN duration = 'full_day' THEN '09:00:00'::TIME
    ELSE '09:00:00'::TIME
  END,
  end_time = CASE 
    WHEN duration = 'half_day' THEN '13:00:00'::TIME
    WHEN duration = 'full_day' THEN '17:00:00'::TIME
    ELSE '17:00:00'::TIME
  END
WHERE start_time IS NULL;

-- 设置字段为非空
ALTER TABLE bookings
ALTER COLUMN start_time SET NOT NULL,
ALTER COLUMN end_time SET NOT NULL;

-- 添加检查约束：结束时间必须晚于开始时间
ALTER TABLE bookings
ADD CONSTRAINT check_time_order CHECK (end_time > start_time);