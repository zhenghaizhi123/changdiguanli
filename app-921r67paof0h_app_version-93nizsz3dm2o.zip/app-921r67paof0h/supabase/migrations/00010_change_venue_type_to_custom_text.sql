-- 将场地类型从枚举改为文本类型，支持自定义类型

-- 1. 添加新的文本类型字段
ALTER TABLE venues
ADD COLUMN type_text TEXT;

-- 2. 将现有数据迁移到新字段
UPDATE venues
SET type_text = CASE 
  WHEN type = 'classroom' THEN '教室'
  WHEN type = 'recruitment_hall' THEN '招聘大厅'
  ELSE type::TEXT
END;

-- 3. 删除旧的枚举类型字段
ALTER TABLE venues
DROP COLUMN type;

-- 4. 重命名新字段为 type
ALTER TABLE venues
RENAME COLUMN type_text TO type;

-- 5. 设置为非空
ALTER TABLE venues
ALTER COLUMN type SET NOT NULL;

-- 6. 添加默认值
ALTER TABLE venues
ALTER COLUMN type SET DEFAULT '教室';

-- 说明：
-- 现在 venues.type 是 TEXT 类型，可以存储任意自定义的场地类型名称
-- 例如：教室、招聘大厅、会议室、培训室、展厅、多功能厅等