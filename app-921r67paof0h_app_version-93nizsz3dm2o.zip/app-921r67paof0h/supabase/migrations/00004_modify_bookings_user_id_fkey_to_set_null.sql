
-- 修改bookings表的user_id外键约束，从CASCADE改为SET NULL
-- 这样删除用户时，预定记录会保留，user_id设置为NULL

-- 1. 删除现有外键约束
ALTER TABLE bookings 
DROP CONSTRAINT IF EXISTS bookings_user_id_fkey;

-- 2. 修改user_id列允许NULL
ALTER TABLE bookings 
ALTER COLUMN user_id DROP NOT NULL;

-- 3. 添加新的外键约束，使用SET NULL
ALTER TABLE bookings 
ADD CONSTRAINT bookings_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES profiles(id) 
ON DELETE SET NULL;

-- 4. 添加注释
COMMENT ON COLUMN bookings.user_id IS '预定用户ID，删除用户时设置为NULL以保留预定记录';
