-- 删除旧的 RLS 策略
DROP POLICY IF EXISTS "所有用户可以查看有效预约的基本信息" ON bookings;

-- 创建新的 RLS 策略：只允许查看已通过审批的预约
CREATE POLICY "所有用户可以查看已通过审批的预约基本信息"
ON bookings
FOR SELECT
TO authenticated
USING (
  status = 'approved'
);

-- 注释：
-- 1. 只有已通过审批的预约（approved）才对所有用户可见
-- 2. 待审核的预约（pending）只有预约人和管理员可见（通过其他策略控制）
-- 3. 这样可以避免误导其他用户，确保日历显示的是真实的已占用时间段