-- 添加签字相关字段到 bookings 表
ALTER TABLE bookings
ADD COLUMN user_signature TEXT,
ADD COLUMN user_signature_date TIMESTAMPTZ,
ADD COLUMN admin_signature TEXT,
ADD COLUMN admin_signature_date TIMESTAMPTZ;

-- 添加注释
COMMENT ON COLUMN bookings.user_signature IS '使用人签字';
COMMENT ON COLUMN bookings.user_signature_date IS '使用人签字时间';
COMMENT ON COLUMN bookings.admin_signature IS '管理员签字';
COMMENT ON COLUMN bookings.admin_signature_date IS '管理员签字时间';