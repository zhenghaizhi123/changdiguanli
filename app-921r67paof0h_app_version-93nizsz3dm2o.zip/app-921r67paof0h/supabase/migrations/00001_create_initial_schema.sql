-- 创建用户角色枚举
CREATE TYPE public.user_role AS ENUM ('user', 'admin');

-- 创建场地类型枚举
CREATE TYPE public.venue_type AS ENUM ('classroom', 'recruitment_hall');

-- 创建预定时间段枚举
CREATE TYPE public.booking_duration AS ENUM ('half_day', 'full_day');

-- 创建预定状态枚举
CREATE TYPE public.booking_status AS ENUM ('pending', 'approved', 'rejected', 'completed', 'cancelled');

-- 创建用户资料表
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  email text,
  phone text,
  role public.user_role NOT NULL DEFAULT 'user'::public.user_role,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建场地表
CREATE TABLE public.venues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type public.venue_type NOT NULL,
  capacity integer NOT NULL,
  location text NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建场地定价表
CREATE TABLE public.venue_pricing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_type public.venue_type NOT NULL UNIQUE,
  half_day_price numeric(10, 2) NOT NULL,
  full_day_price numeric(10, 2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 创建预定表
CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid NOT NULL REFERENCES public.venues(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  booking_date date NOT NULL,
  duration public.booking_duration NOT NULL,
  status public.booking_status NOT NULL DEFAULT 'pending'::public.booking_status,
  original_price numeric(10, 2) NOT NULL,
  final_price numeric(10, 2) NOT NULL,
  organization_name text,
  contact_person text,
  contact_phone text,
  purpose text,
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(venue_id, booking_date, duration)
);

-- 创建索引
CREATE INDEX idx_bookings_user_id ON public.bookings(user_id);
CREATE INDEX idx_bookings_venue_id ON public.bookings(venue_id);
CREATE INDEX idx_bookings_date ON public.bookings(booking_date);
CREATE INDEX idx_bookings_status ON public.bookings(status);

-- 创建更新时间触发器函数
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- 为所有表添加更新时间触发器
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_venues_updated_at
  BEFORE UPDATE ON public.venues
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_venue_pricing_updated_at
  BEFORE UPDATE ON public.venue_pricing
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- 创建用户同步触发器函数
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  extracted_username text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  
  -- 从邮箱中提取用户名（去掉@miaoda.com）
  extracted_username := SPLIT_PART(NEW.email, '@', 1);
  
  INSERT INTO public.profiles (id, username, email, phone, role)
  VALUES (
    NEW.id,
    extracted_username,
    NEW.email,
    NEW.phone,
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END
  );
  RETURN NEW;
END;
$$;

-- 创建用户确认触发器
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- 创建管理员检查函数
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean 
LANGUAGE sql 
SECURITY DEFINER 
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- 启用RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.venue_pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Profiles表策略
CREATE POLICY "管理员可以查看所有用户资料" ON public.profiles
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以查看自己的资料" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "管理员可以更新所有用户资料" ON public.profiles
  FOR UPDATE TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以更新自己的资料（除角色外）" ON public.profiles
  FOR UPDATE TO authenticated 
  USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- Venues表策略
CREATE POLICY "所有认证用户可以查看场地" ON public.venues
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "管理员可以管理场地" ON public.venues
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Venue_pricing表策略
CREATE POLICY "所有认证用户可以查看定价" ON public.venue_pricing
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "管理员可以管理定价" ON public.venue_pricing
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Bookings表策略
CREATE POLICY "用户可以查看自己的预定" ON public.bookings
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "管理员可以查看所有预定" ON public.bookings
  FOR SELECT TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "用户可以创建预定" ON public.bookings
  FOR INSERT TO authenticated 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以取消自己的预定" ON public.bookings
  FOR UPDATE TO authenticated 
  USING (auth.uid() = user_id AND status IN ('pending', 'approved'))
  WITH CHECK (status = 'cancelled'::public.booking_status);

CREATE POLICY "管理员可以管理所有预定" ON public.bookings
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- 创建公开视图
CREATE VIEW public_profiles AS
  SELECT id, username, role FROM profiles;

-- 插入默认定价数据
INSERT INTO public.venue_pricing (venue_type, half_day_price, full_day_price) VALUES
  ('classroom'::public.venue_type, 500.00, 800.00),
  ('recruitment_hall'::public.venue_type, 1000.00, 1800.00);

-- 插入示例场地数据
INSERT INTO public.venues (name, type, capacity, location, description) VALUES
  ('第一教室', 'classroom'::public.venue_type, 50, '一楼东侧', '配备投影仪和音响设备，适合培训和讲座'),
  ('第二教室', 'classroom'::public.venue_type, 30, '一楼西侧', '小型教室，适合小组讨论和培训'),
  ('第三教室', 'classroom'::public.venue_type, 80, '二楼中央', '大型教室，配备完善的多媒体设备'),
  ('A区招聘大厅', 'recruitment_hall'::public.venue_type, 200, '三楼A区', '大型招聘场地，可容纳50个展位'),
  ('B区招聘大厅', 'recruitment_hall'::public.venue_type, 150, '三楼B区', '中型招聘场地，可容纳30个展位');
