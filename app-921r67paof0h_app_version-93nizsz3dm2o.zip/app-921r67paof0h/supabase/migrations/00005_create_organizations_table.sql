-- 创建单位管理表
CREATE TABLE IF NOT EXISTS organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_organizations_name ON organizations(name);
CREATE INDEX IF NOT EXISTS idx_organizations_is_active ON organizations(is_active);

-- 插入一些默认单位
INSERT INTO organizations (name, description) VALUES
  ('苏州市人才市场', '苏州市人才市场主办单位'),
  ('苏州工业园区人力资源服务中心', '园区人力资源服务机构'),
  ('苏州高新区人才市场', '高新区人才服务机构'),
  ('苏州市人力资源和社会保障局', '市人社局'),
  ('个人', '个人预约')
ON CONFLICT (name) DO NOTHING;

-- RLS 策略
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;

-- 所有用户可以查看激活的单位
CREATE POLICY "所有用户可以查看激活的单位"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (is_active = true);

-- 只有管理员可以管理单位
CREATE POLICY "管理员可以管理单位"
  ON organizations
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );