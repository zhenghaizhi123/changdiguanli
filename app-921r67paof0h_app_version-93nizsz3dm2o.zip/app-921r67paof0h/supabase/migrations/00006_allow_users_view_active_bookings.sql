-- 允许所有认证用户查看有效预约的基本信息（用于冲突检测和预约提示）
-- 这个策略只允许查看 pending 和 approved 状态的预约
-- 只返回必要的字段：start_time, end_time, organization_name, booking_date, venue_id

CREATE POLICY "所有用户可以查看有效预约的基本信息" ON public.bookings
  FOR SELECT TO authenticated 
  USING (status IN ('pending', 'approved'));

-- 注意：这个策略与现有的策略是 OR 关系
-- 用户可以：
-- 1. 查看自己的所有预约（通过"用户可以查看自己的预定"策略）
-- 2. 查看所有有效预约的基本信息（通过这个新策略）
-- 管理员可以：
-- 1. 查看所有预约（通过"管理员可以查看所有预定"策略）
