-- 删除不合理的唯一约束
-- 该约束限制了同一场地同一天相同duration只能有一个预约
-- 这不符合业务需求：同一天应该可以有多个预约，只要时间不冲突即可

ALTER TABLE bookings
DROP CONSTRAINT IF EXISTS bookings_venue_id_booking_date_duration_key;

-- 说明：
-- 时间冲突检测已经在应用层实现（checkVenueAvailability 函数）
-- 通过比较 start_time 和 end_time 来判断是否冲突
-- 不需要通过 duration 字段来限制预约数量