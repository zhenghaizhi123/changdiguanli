-- 为venues表添加自定义定价字段
ALTER TABLE venues
ADD COLUMN half_day_price DECIMAL(10, 2),
ADD COLUMN full_day_price DECIMAL(10, 2);

-- 将现有场地的价格从venue_pricing表复制到venues表
UPDATE venues v
SET 
  half_day_price = vp.half_day_price,
  full_day_price = vp.full_day_price
FROM venue_pricing vp
WHERE v.type = vp.venue_type;

-- 将价格字段设为必填
ALTER TABLE venues
ALTER COLUMN half_day_price SET NOT NULL,
ALTER COLUMN full_day_price SET NOT NULL;

-- 添加价格字段的检查约束
ALTER TABLE venues
ADD CONSTRAINT venues_half_day_price_positive CHECK (half_day_price >= 0),
ADD CONSTRAINT venues_full_day_price_positive CHECK (full_day_price >= 0);

-- 更新注释
COMMENT ON COLUMN venues.half_day_price IS '场地半天价格';
COMMENT ON COLUMN venues.full_day_price IS '场地全天价格';