-- 在 bookings 表中添加管理员备注字段
ALTER TABLE bookings
ADD COLUMN admin_note TEXT;

COMMENT ON COLUMN bookings.admin_note IS '管理员备注：用于记录改价原因、审核说明等信息';